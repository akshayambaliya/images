package org.rbsoft.smsgateway.receivers;

import android.content.Context;
import android.net.Uri;
import android.util.Log;

public class MmsReceivedReceiver extends com.klinker.android.send_message.MmsReceivedReceiver {
    @Override
    public void onMessageReceived(Context context, Uri messageUri) {
        Log.d("MmsReceived", "message received: " + messageUri.toString());
    }

    @Override
    public void onError(Context context, String error) {
        Log.d("MmsReceived", "error: " + error);
    }
}

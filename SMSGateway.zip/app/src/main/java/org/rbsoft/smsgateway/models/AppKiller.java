package org.rbsoft.smsgateway.models;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.widget.TextView;

import org.rbsoft.smsgateway.R;

import static org.rbsoft.smsgateway.others.Common.PREF_SETTINGS;

import androidx.core.text.HtmlCompat;

public class AppKiller {

    private String message;

    private String title;

    private Intent intent;

    private Context context;

    private AppKiller(Builder builder) {
        context = builder.context;
        message = builder.message;
        title = builder.title;
        intent = builder.intent;
    }

    private String getMessage() {
        return TextUtils.isEmpty(message) ? context.getString(R.string.dialog_whitelist_message) : message;
    }

    private String getTitle() {
        return TextUtils.isEmpty(title) ? context.getString(R.string.dialog_whitelist_title) : title;
    }

    public boolean showDialog(String preference) {
        if (context.getPackageManager().resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY) != null) {
            AlertDialog alertDialog = new android.app.AlertDialog.Builder(context)
                    .setMessage(HtmlCompat.fromHtml(getMessage(), HtmlCompat.FROM_HTML_MODE_LEGACY))
                    .setTitle(getTitle())
                    .setCancelable(false)
                    .setPositiveButton(R.string.button_ok, (dialog, which) -> {
                        try {
                            context.startActivity(intent);
                        } catch (Exception e) {
                            disableCheck(preference);
                        }
                    })
                    .setNegativeButton(R.string.button_never_ask_again, (dialog, which) -> {
                        disableCheck(preference);
                    })
                    .create();
            alertDialog.show();
            TextView textView = alertDialog.findViewById(android.R.id.message);
            textView.setLinksClickable(true);
            textView.setClickable(true);
            textView.setMovementMethod(LinkMovementMethod.getInstance());
            return true;
        }
        return false;
    }

    private void disableCheck(String preference) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREF_SETTINGS, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(preference, false);
        editor.apply();
    }

    public static class Builder {

        private String message;

        private String title;

        private Intent intent;

        private Context context;

        public Builder(Context context, Intent intent) {
            this.context = context;
            this.intent = intent;
        }

        public Builder setMessage(int resId) {
            this.message = context.getString(resId);
            return this;
        }

        public Builder setMessage(String message) {
            this.message = message;
            return this;
        }

        public Builder setTitle(int resId) {
            this.title = context.getString(resId);
            return this;
        }

        public AppKiller create() {
            return new AppKiller(this);
        }
    }
}
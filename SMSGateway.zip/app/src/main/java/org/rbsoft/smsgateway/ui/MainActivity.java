package org.rbsoft.smsgateway.ui;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.DownloadManager;
import android.app.job.JobScheduler;
import android.app.role.RoleManager;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;

import androidx.annotation.RequiresApi;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.appcompat.widget.Toolbar;

import android.os.Handler;
import android.os.Looper;
import android.provider.Telephony;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewTreeObserver;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.gson.JsonSyntaxException;

import org.rbsoft.smsgateway.*;
import org.rbsoft.smsgateway.models.*;
import org.rbsoft.smsgateway.services.GetCampaignsService;
import org.rbsoft.smsgateway.services.MyWebService;
import org.rbsoft.smsgateway.services.SendMessagesService;

import java.io.EOFException;
import java.io.IOException;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.annotation.Nonnull;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static org.rbsoft.smsgateway.others.Common.*;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private static final String TAG = MainActivity.class.getSimpleName();

    private ValueCallback<Uri[]> mUploadMessage;
    private String mLastUrl;
    private String mServer;
    private int mDeviceId;
    private String mDeviceModel;
    private int mUserId;
    private List<String> mCookie;
    private String mSessionId;
    private String mSenderId;
    private SharedPreferences mSettings;
    private String mPackageName;

    private Boolean mRunning = false;

    private WebView mWebView;
    private NavigationView mNavigationView;
    private DrawerLayout mDrawer;
    private SwipeRefreshLayout mSwipeRefreshLayout;

    private Toast mToast;
    private Toast mErrorToast;
    private Call<JsonResponse> mSignInCall;
    private FloatingActionButton mFab;

    private boolean mSignOutVisible = false;

    private ViewTreeObserver.OnScrollChangedListener mOnScrollChangedListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "onCreate");

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        cancelSendingMessages(this.getIntent());

        initPreferences();
        initAppKillers();

        initViews();
        initActions();

        getSessionId();
    }

    ActivityResultLauncher<Intent> makeDefaultAppDialog = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    if (Objects.equals(Telephony.Sms.getDefaultSmsPackage(this), mPackageName)) {
                        Menu menu = mNavigationView.getMenu();
                        menu.findItem(R.id.nav_make_default).setVisible(false);
                    }
                }
            });

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        cancelSendingMessages(intent);
    }

    ActivityResultLauncher<Intent> selectFileDialog = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    if (mUploadMessage == null)
                        return;
                    mUploadMessage.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result.getResultCode(), result.getData()));
                    mUploadMessage = null;
                }
            });

    private void initAppKillers() {
        if (mSettings.getBoolean(PREF_CHECK_AUTO_START_MANAGERS, true)) {
            /*
             * @see <a href="https://github.com/dirkam/backgroundable-android">backgroundable-android</a>
             * @see <a href="https://stackoverflow.com/questions/31638986/protected-apps-setting-on-huawei-phones-and-how-to-handle-it">Enable AutoStart</a>
             */
            final AppKiller[] autoStartManagers = {
                    new AppKiller.Builder(this, new Intent("miui.intent.action.OP_AUTO_START").addCategory(Intent.CATEGORY_DEFAULT))
                            .setMessage(R.string.dialog_xiaomi_autostart_message)
                            .setTitle(R.string.dialog_xiaomi_autostart_title)
                            .create(),
                    new AppKiller.Builder(this, new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity")))
                            .create(),
                    new AppKiller.Builder(this, new Intent().setComponent(new ComponentName("com.huawei.systemmanager", Build.VERSION.SDK_INT >= Build.VERSION_CODES.P ? "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity" : "com.huawei.systemmanager.appcontrol.activity.StartupAppControlActivity")))
                            .create(),
                    new AppKiller.Builder(this, new Intent().setComponent(new ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity")))
                            .create(),
                    new AppKiller.Builder(this, new Intent().setComponent(new ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.BgStartUpManager")))
                            .create(),
                    new AppKiller.Builder(this, new Intent().setComponent(new ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity")))
                            .create(),
                    new AppKiller.Builder(this, new Intent().setComponent(new ComponentName("com.samsung.android.lool", "com.samsung.android.sm.ui.battery.BatteryActivity")))
                            .create(),
                    new AppKiller.Builder(this, new Intent().setComponent(new ComponentName("com.htc.pitroad", "com.htc.pitroad.landingpage.activity.LandingPageActivity")))
                            .create(),
                    new AppKiller.Builder(this, new Intent().setComponent(new ComponentName("com.asus.mobilemanager", "com.asus.mobilemanager.entry.FunctionActivity")).setData(android.net.Uri.parse("mobilemanager://function/entry/AutoStart")))
                            .create(),
                    new AppKiller.Builder(this, new Intent().setComponent(new ComponentName("com.asus.mobilemanager", "com.asus.mobilemanager.autostart.AutoStartActivity")))
                            .create(),
                    new AppKiller.Builder(this, new Intent().setComponent(new ComponentName("com.letv.android.letvsafe", "com.letv.android.letvsafe.AutobootManageActivity"))
                            .setData(android.net.Uri.parse("mobilemanager://function/entry/AutoStart")))
                            .create(),
                    new AppKiller.Builder(this, new Intent().setComponent(new ComponentName("com.meizu.safe", "com.meizu.safe.security.SHOW_APPSEC")).addCategory(Intent.CATEGORY_DEFAULT).putExtra("packageName", BuildConfig.APPLICATION_ID))
                            .create(),
                    new AppKiller.Builder(this, new Intent().setComponent(new ComponentName("com.dewav.dwappmanager", "com.dewav.dwappmanager.memory.SmartClearupWhiteList")))
                            .create(),
                    new AppKiller.Builder(this, new Intent().setComponent(new ComponentName("com.transsion.phonemanager", "com.itel.autobootmanager.activity.AutoBootMgrActivity")))
                            .create()

            };

            for (final AppKiller appKiller : autoStartManagers) {
                if (appKiller != null) {
                    if (appKiller.showDialog(PREF_CHECK_AUTO_START_MANAGERS)) {
                        break;
                    }
                }
            }
        }

        if (mSettings.getBoolean(PREF_CHECK_BATTERY_SAVERS, true)) {
            final AppKiller[] batterySavers = {
                    new AppKiller.Builder(this, new Intent("miui.intent.action.POWER_HIDE_MODE_APP_LIST").addCategory(Intent.CATEGORY_DEFAULT))
                            .setMessage(R.string.dialog_xiaomi_batter_saver_message)
                            .setTitle(R.string.dialog_xiaomi_batter_saver_title)
                            .create()
            };

            for (final AppKiller appKiller : batterySavers) {
                if (appKiller.showDialog(PREF_CHECK_BATTERY_SAVERS)) {
                    break;
                }
            }
        }
    }

    private void initPreferences() {
        mSettings = getSharedPreferences(PREF_SETTINGS, Context.MODE_PRIVATE);
        mServer = mSettings.getString(PREF_SERVER, null);
        mSenderId = mSettings.getString(PREF_SENDER_ID, null);
        mUserId = mSettings.getInt(PREF_USER_ID, 0);

        if (mServer == null || mSenderId == null || mUserId == 0) {
            clearDataAndSignIn();
        }
    }

    private void initViews() {
        mDrawer = findViewById(R.id.drawer_layout);
        mNavigationView = findViewById(R.id.nav_view);
        mSwipeRefreshLayout = this.findViewById(R.id.swipe_refresh_layout);
        mWebView = findViewById(R.id.web_view);
    }

    private void setRunning(boolean running) {
        this.mRunning = running;

        if (this.mRunning) {
            mFab.setImageDrawable(ContextCompat.getDrawable(this, android.R.drawable.ic_lock_power_off));
        } else {
            mFab.setImageDrawable(ContextCompat.getDrawable(this, android.R.drawable.ic_media_play));
        }

        if (mSettings.getBoolean(PREF_SERVICE_RUNNING, false) != running) {
            SharedPreferences.Editor editor = mSettings.edit();
            editor.putBoolean(PREF_SERVICE_RUNNING, running);
            editor.apply();
        }
    }

    protected void onResume() {
        super.onResume();
        Menu menu = mNavigationView.getMenu();
        MenuItem setDefaultMenuItem = menu.findItem(R.id.nav_make_default);
        if (Objects.equals(Telephony.Sms.getDefaultSmsPackage(this), mPackageName)) {
            setDefaultMenuItem.setVisible(false);
        } else {
            setDefaultMenuItem.setVisible(true);
            if (mSettings.getBoolean(PREF_CHECK_DEFAULT_APP, true) && !this.isFinishing()) {
                AlertDialog alertDialog = new AlertDialog.Builder(this)
                        .setMessage(R.string.dialog_set_app_default_message)
                        .setTitle(R.string.dialog_set_app_default_title)
                        .setCancelable(false)
                        .setPositiveButton(R.string.button_yes, (dialog, which) -> setAsDefaultSmsApp())
                        .setNegativeButton(R.string.button_no, null)
                        .setNeutralButton(R.string.button_never_ask_again, (dialog, which) -> {
                            SharedPreferences.Editor editor = mSettings.edit();
                            editor.putBoolean(PREF_CHECK_DEFAULT_APP, false);
                            editor.apply();
                        })
                        .create();
                alertDialog.show();
            }
        }
    }

    private void toggleService() {
        Intent intent = new Intent(MainActivity.this, GetCampaignsService.class);
        if (mRunning) {
            stopService(intent);
            setRunning(false);
            Snackbar.make(mFab, R.string.service_stopped, Snackbar.LENGTH_LONG).show();
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent);
            } else {
                startService(intent);
            }
            setRunning(true);
            Snackbar.make(mFab, R.string.service_started, Snackbar.LENGTH_LONG).show();
        }
    }

    private void cancelSendingMessages(Intent intent) {
        if (Objects.equals(intent.getAction(), SendMessagesService.ACTION_STOP_SENDING_MESSAGES)) {
            AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
            alertDialog.setMessage(R.string.dialog_cancel_sending_messages_message);
            alertDialog.setTitle(R.string.dialog_cancel_sending_messages_title);
            alertDialog.setPositiveButton(R.string.button_yes,
                    (dialog, which) -> SendMessagesService.cancel = true
            );
            alertDialog.setNegativeButton(R.string.button_no, null);
            alertDialog.setCancelable(false);
            alertDialog.create().show();
        }
    }

    private void showErrorToast(String message) {
        if (mErrorToast != null) {
            mErrorToast.cancel();
        }
        mErrorToast = Toast.makeText(this, message, Toast.LENGTH_LONG);
        mErrorToast.show();
    }

    private void showErrorPage(boolean noConnection, String message) {
        showProgress(false);
        setSignOutVisibility(true);
        showErrorToast(message);
        if (noConnection) {
            mWebView.loadUrl("file:///android_asset/error.html");
        } else {
            mWebView.loadUrl("file:///android_asset/error-server.html");
        }
    }

    private void clearDataAndSignIn() {
        Log.d(TAG, "clearDataAndSignIn");
        SharedPreferences.Editor editor = mSettings.edit();
        editor.remove(PREF_USER_ID);
        editor.remove(PREF_SENDER_ID);
        editor.apply();
        if (mRunning) {
            toggleService();
        }
        Log.d(TAG, "launchLoginActivity : Launching LoginActivity.");
        Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
        startActivity(intent);
        finish();
    }

    private void showProgress(boolean show) {
        if (mSwipeRefreshLayout.isRefreshing() != show) {
            Log.d(TAG, String.format("showProgress : Changed mSwipeRefreshLayout.setRefreshing to %b", show));
            mSwipeRefreshLayout.setEnabled(!show);
            mSwipeRefreshLayout.setRefreshing(show);
        }
    }

    private void signOut() {
        Log.d(TAG, "signOut");
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
        alertDialog.setMessage(R.string.dialog_sign_out_message);
        alertDialog.setTitle(R.string.dialog_sign_out_title);
        alertDialog.setPositiveButton(R.string.button_yes,
                (dialog, which) -> {
                    setSignOutVisibility(false);
                    if (mSignInCall != null) {
                        mSignInCall.cancel();
                    }
                    mWebView.stopLoading();
                    mDrawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);
                    showProgress(true);
                    MyWebService myWebService = getWebService(mServer);
                    Call<JsonResponse> call = myWebService.signOut(getAndroidId(getApplicationContext()), mUserId);
                    call.enqueue(new Callback<JsonResponse>() {
                        @Override
                        public void onResponse(@NonNull Call<JsonResponse> call, @NonNull Response<JsonResponse> response) {
                            showProgress(false);
                            if (response.isSuccessful()) {
                                JsonResponse jsonResponse = response.body();
                                if (jsonResponse != null) {
                                    if (jsonResponse.getSuccess()) {
                                        clearDataAndSignIn();
                                    } else {
                                        showRequestErrorToast(jsonResponse.getError().getMessage());
                                    }
                                }
                            } else {
                                showRequestErrorToast(String.format("%s %s", response.code(), response.message()));
                            }
                        }

                        @Override
                        public void onFailure(@NonNull Call<JsonResponse> call, @NonNull Throwable t) {
                            if (t instanceof com.google.gson.stream.MalformedJsonException || t instanceof JsonSyntaxException || t instanceof IllegalStateException || t instanceof EOFException) {
                                showRequestErrorToast(getString(R.string.error_invalid_response));
                            } else {
                                showRequestErrorToast(t.getMessage());
                            }
                        }
                    });
                }
        );
        alertDialog.setNegativeButton(R.string.button_no, null);
        alertDialog.setCancelable(true);
        alertDialog.create().show();
    }

    private void showRequestErrorToast(String message) {
        setSignOutVisibility(true);
        if (!TextUtils.isEmpty(mSessionId)) {
            mDrawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);
        }
        showProgress(false);
        showErrorToast(message);
    }

    private void loadUrl(String url) {
        if (!Objects.equals(mWebView.getUrl(), url)) {
            mWebView.stopLoading();
            Log.d(TAG, String.format("loadUrl : %s", url));
            mWebView.loadUrl(url);
        }
    }

    private void setSignOutVisibility(boolean visible) {
        mSignOutVisible = visible;
        invalidateOptionsMenu();
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void initActions() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, mDrawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        mDrawer.addDrawerListener(toggle);
        mDrawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);
        toggle.syncState();

        mNavigationView.setNavigationItemSelectedListener(this);
        mPackageName = getPackageName();

        SwitchCompat switchCompatReadReceived = mNavigationView.getMenu().findItem(R.id.nav_read_received).getActionView().findViewById(R.id.action_read_received);
        switchCompatReadReceived.setChecked(mSettings.getBoolean(PREF_READ_RECEIVED, true));
        switchCompatReadReceived.setOnCheckedChangeListener((buttonView, isChecked) -> {
            SharedPreferences.Editor editor = mSettings.edit();
            editor.putBoolean(PREF_READ_RECEIVED, isChecked);
            editor.apply();
            if (!isChecked) {
                JobScheduler jobScheduler = (JobScheduler) getSystemService(Context.JOB_SCHEDULER_SERVICE);
                jobScheduler.cancel(RECEIVER_JOB_ID);
                Log.d(TAG, "Cancelled periodic sms receiver job recurring every 30 minutes.");
            }
        });

        mFab = findViewById(R.id.fab);
        mFab.setOnClickListener(view -> {
            if (mRunning) {
                toggleService();
            } else {
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
                alertDialog.setMessage(R.string.dialog_start_service_warning_message);
                alertDialog.setTitle(R.string.dialog_start_service_warning_title);
                alertDialog.setPositiveButton(R.string.button_yes,
                        (dialog, which) -> toggleService()
                );
                alertDialog.setNegativeButton(R.string.button_no, null);
                alertDialog.setCancelable(false);
                alertDialog.create().show();
            }
        });

        ActivityManager activityManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : activityManager.getRunningServices(Integer.MAX_VALUE)) {
            if (GetCampaignsService.class.getName().equals(service.service.getClassName())) {
                setRunning(true);
                break;
            }
        }

        if (!mRunning && mSettings.getBoolean(PREF_SERVICE_RUNNING, false)) {
            toggleService();
        }

        mSwipeRefreshLayout.setEnabled(false);
        mSwipeRefreshLayout.setOnRefreshListener(
                () -> {
                    Log.d(TAG, String.format("SwipeRefreshLayout.OnRefreshListener() : Current url is %s", mWebView.getUrl()));
                    // If current url that user is trying to refresh is local error page then
                    // it means we need reload to last url that was unable to load not the error page.
                    // So we are checking for it.
                    if (mWebView.getUrl() != null && mWebView.getUrl().contains("file:///android_asset")) {
                        // If session id is empty then it means we are not logged in so we need to log in first using web request.
                        if (TextUtils.isEmpty(mSessionId)) {
                            getSessionId();
                        } else {
                            mWebView.loadUrl(mLastUrl);
                        }
                    } else {
                        mWebView.reload();
                    }
                }
        );

        mWebView.addJavascriptInterface(new WebAppInterface(this), "Android");
        mWebView.setWebViewClient(new MyWebViewClient());
        mWebView.setWebChromeClient(new MyWebChromeClient());
        WebSettings webSettings = mWebView.getSettings();
        webSettings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);

        // We need to listen for downloadable files to download exported excel file containing messages sent by users.
        mWebView.setDownloadListener(
                (url, userAgent, contentDisposition, mimeType, contentLength) -> {
                    DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                    request.setMimeType(mimeType);
                    // We need to pass cookie to download request cause you can't download exported excel file until you are logged in.
                    // Which requires cookie to be present with session id of the current session.
                    String cookies = CookieManager.getInstance().getCookie(url);
                    request.addRequestHeader("cookie", cookies);
                    request.addRequestHeader("User-Agent", userAgent);
                    String fileName = "";
                    if (!TextUtils.isEmpty(contentDisposition)) {
                        // We are sending file name in content disposition header. So we need to parse it and extract the file name from it.
                        String[] contentDispositionSplit = contentDisposition.split(";");
                        if (contentDispositionSplit.length > 1) {
                            fileName = contentDispositionSplit[1].replace("filename=", "").replace("\"", "");
                        }
                    }
                    if (TextUtils.isEmpty(fileName)) {
                        fileName = URLUtil.guessFileName(url, contentDisposition, mimeType);
                    }
                    request.setTitle(fileName);
                    request.setDescription("Downloading file...");
                    request.allowScanningByMediaScanner();
                    request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);
                    DownloadManager downloadManager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                    if (downloadManager != null) {
                        downloadManager.enqueue(request);
                    }
                }
        );
    }

    private void getSessionId() {
        if (!isFinishing()) {
            Log.d(TAG, "getSessionId : Getting session id from the server.");
            mSessionId = "";
            setSignOutVisibility(false);
            mDrawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);
            showProgress(true);
            MyWebService myWebService = getWebService(mServer);
            String sims = getAllSims(MainActivity.this);
            String androidVersion = Build.VERSION.RELEASE;
            String appVersion = BuildConfig.VERSION_NAME;
            mSignInCall = myWebService.signIn(getAndroidId(getApplicationContext()), mUserId, sims, androidVersion, appVersion);
            mSignInCall.enqueue(new Callback<JsonResponse>() {
                @Override
                public void onResponse(@NonNull Call<JsonResponse> call, @NonNull Response<JsonResponse> response) {
                    if (response.isSuccessful()) {
                        JsonResponse jsonResponse = response.body();
                        if (jsonResponse != null) {
                            if (jsonResponse.getSuccess()) {
                                mCookie = response.headers().values("set-cookie");
                                ExecutorService executor = Executors.newSingleThreadExecutor();
                                Handler handler = new Handler(Looper.getMainLooper());
                                executor.execute(() -> {
                                    try {
                                        Update.check(MainActivity.this);
                                        String token = FirebaseInstanceId.getInstance().getToken(mSenderId, "FCM");
                                        handler.post(() -> {
                                            showProgress(false);
                                            if (Objects.equals(token, jsonResponse.getData().getDevice().getToken())) {
                                                mSessionId = jsonResponse.getData().getSessionId();
                                                mDeviceId = jsonResponse.getData().getDevice().getID();
                                                mDeviceModel = jsonResponse.getData().getDevice().getModel();
                                                View headerView = mNavigationView.getHeaderView(0);
                                                TextView textViewName = headerView.findViewById(R.id.text_name);
                                                TextView textViewDeviceName = headerView.findViewById(R.id.text_device_name);
                                                TextView textViewEmail = headerView.findViewById(R.id.text_email);
                                                textViewName.setText(jsonResponse.getData().getDevice().getUser().getName());
                                                String name = String.format("%s [%s]", mDeviceModel, mDeviceId);
                                                if (!TextUtils.isEmpty(jsonResponse.getData().getDevice().getName())) {
                                                    name = String.format("%s [%s]", jsonResponse.getData().getDevice().getName(), jsonResponse.getData().getDevice().getID());
                                                }
                                                textViewDeviceName.setText(name);
                                                textViewEmail.setText(jsonResponse.getData().getDevice().getUser().getEmail());
                                                Menu menu = mNavigationView.getMenu();
                                                MenuItem manageUsersMenuItem = menu.findItem(R.id.nav_manage_users);
                                                if (manageUsersMenuItem != null) {
                                                    manageUsersMenuItem.setVisible(jsonResponse.getData().getDevice().getUser().getIsAdmin() == 1);
                                                }
                                                CookieManager cookieManager = CookieManager.getInstance();
                                                cookieManager.setAcceptThirdPartyCookies(mWebView, true);
                                                cookieManager.removeAllCookies(aBoolean -> {
                                                    for (String value : mCookie) {
                                                        cookieManager.setCookie(Uri.parse(mServer).getHost(), value);
                                                    }
                                                    cookieManager.setCookie(Uri.parse(mServer).getHost(), String.format("DEVICE_ID=%s", mDeviceId));
                                                    mWebView.loadUrl(String.format("%sdashboard.php", mServer));
                                                    menu.findItem(R.id.nav_dashboard).setChecked(true);
                                                    mDrawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);
                                                    setSignOutVisibility(true);
                                                });
                                            } else {
                                                clearDataAndSignIn();
                                            }
                                        });
                                    } catch (IOException e) {
                                        handler.post(() -> showErrorPage(true, e.getMessage()));
                                    } catch (Exception e) {
                                        handler.post(() -> clearDataAndSignIn());
                                    }
                                });
                            } else {
                                if (jsonResponse.getError().getCode() > 401) {
                                    showErrorPage(false, jsonResponse.getError().getMessage());
                                } else {
                                    clearDataAndSignIn();
                                }
                            }
                        }
                    } else {
                        showErrorPage(false, String.format("%s %s", response.code(), response.message()));
                    }
                }

                @Override
                public void onFailure(@NonNull Call<JsonResponse> call, @NonNull Throwable t) {
                    if (call.isCanceled()) {
                        Log.d(TAG, "Sign In service call cancelled.");
                        return;
                    }

                    if (t instanceof com.google.gson.stream.MalformedJsonException || t instanceof JsonSyntaxException || t instanceof IllegalStateException || t instanceof EOFException) {
                        showErrorPage(false, getString(R.string.error_invalid_response));
                    } else {
                        showErrorPage(true, t.getMessage());
                    }
                }
            });
        }
    }

    @Override
    public void onConfigurationChanged(@Nonnull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        MenuItem mActionSignOut = menu.findItem(R.id.action_sign_out);
        mActionSignOut.setVisible(mSignOutVisible);
        Log.d(TAG, String.format("onCreateOptionsMenu : Sign out button visibility is set to %b", mActionSignOut.isVisible()));
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        if (id == R.id.action_sign_out) {
            signOut();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        String server = mSettings.getString(PREF_SERVER, "");
        if (id == R.id.nav_dashboard) {
            loadUrl(server + "dashboard.php");
        } else if (id == R.id.nav_messages) {
            loadUrl(server + "messages.php");
        } else if (id == R.id.nav_manage_users) {
            loadUrl(server + "manage-users.php");
        } else if (id == R.id.nav_templates) {
            loadUrl(server + "templates.php");
        } else if (id == R.id.nav_contacts) {
            loadUrl(server + "contacts.php");
        } else if (id == R.id.nav_auto_responder) {
            loadUrl(server + "auto-responder.php");
        } else if (id == R.id.nav_profile) {
            loadUrl(server + "profile.php");
        } else if (id == R.id.nav_devices) {
            loadUrl(server + "devices.php");
        } else if (id == R.id.nav_sender) {
            loadUrl(server + "sender.php");
        } else if (id == R.id.nav_read_received) {
            return false;
        } else if (id == R.id.nav_make_default) {
            if (!Objects.equals(Telephony.Sms.getDefaultSmsPackage(this), mPackageName)) {
                setAsDefaultSmsApp();
            }
            return false;
        }

        mDrawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onStart() {
        Log.d(TAG, "onStart");
        mSwipeRefreshLayout.getViewTreeObserver().addOnScrollChangedListener(mOnScrollChangedListener =
                () -> {
                    if (mWebView.getScrollY() == 0)
                        mSwipeRefreshLayout.setEnabled(true);
                    else {
                        if (!mSwipeRefreshLayout.isRefreshing()) {
                            mSwipeRefreshLayout.setEnabled(false);
                        }
                    }
                }
        );
        super.onStart();
    }

    @Override
    public void onStop() {
        Log.d(TAG, "onStop");
        mSwipeRefreshLayout.getViewTreeObserver().removeOnScrollChangedListener(mOnScrollChangedListener);
        super.onStop();
    }

    @Override
    public void onBackPressed() {
        Log.d(TAG, "onBackPressed");
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            if (mErrorToast != null) {
                mErrorToast.cancel();
            }

            if (mToast != null) {
                mToast.cancel();
                finishAndRemoveTask();
            } else {
                mToast = Toast.makeText(this, R.string.toast_message_exit, Toast.LENGTH_SHORT);
                mToast.show();

                final Handler handler = new Handler(Looper.getMainLooper());
                handler.postDelayed(() -> mToast = null, 2000);
            }
        }
    }

    private class WebAppInterface {
        Context mContext;

        /**
         * Instantiate the interface and set the context
         */
        WebAppInterface(Context c) {
            mContext = c;
        }

        /**
         * Change device name from the web page.
         */
        @JavascriptInterface
        public void changeDeviceName(String name) {
            runOnUiThread(() -> {
                Log.d(TAG, String.format("changeDeviceName : Changed device name to %s", name));
                View headerView = mNavigationView.getHeaderView(0);
                TextView textViewDeviceName = headerView.findViewById(R.id.text_device_name);
                if (TextUtils.isEmpty(name)) {
                    textViewDeviceName.setText(String.format("%s [%s]", mDeviceModel, mDeviceId));
                } else {
                    textViewDeviceName.setText(String.format("%s [%s]", name, mDeviceId));
                }
            });
        }

        /**
         * Change Name from the web page.
         */
        @JavascriptInterface
        public void changeName(String name) {
            runOnUiThread(() -> {
                Log.d(TAG, String.format("changeName : Changed user name to %s", name));
                View headerView = mNavigationView.getHeaderView(0);
                TextView textViewName = headerView.findViewById(R.id.text_name);
                textViewName.setText(name);
            });
        }
    }

    private class MyWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            Log.d(TAG, String.format("shouldOverrideUrlLoading : %s", url));
            String server = mSettings.getString(PREF_SERVER, "");
            if (url.equals(String.format("%sindex.php", server))) {
                getSessionId();
                return true;
            }
            if (url.contains(server)) {
                // This is my web site, so do not override; let my WebView load the page
                return false;
            }
            // Otherwise, the link is not for a page on my site, so launch another Activity that handles URLs
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
            return true;
        }

        @RequiresApi(api = Build.VERSION_CODES.N)
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return shouldOverrideUrlLoading(view, request.getUrl().toString());
        }

        public void onPageFinished(WebView view, String url) {
            Log.d(TAG, String.format("onPageFinished : %s", url));
            showProgress(false);
        }

        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            Log.d(TAG, String.format("onPageStarted : %s", url));
            showProgress(true);
            if (url.contains("messages.php")) {
                Menu menu = mNavigationView.getMenu();
                menu.findItem(R.id.nav_messages).setChecked(true);
            }
        }

        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            mLastUrl = failingUrl;
            mWebView.loadUrl("file:///android_asset/error.html");
        }

        @RequiresApi(api = Build.VERSION_CODES.M)
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            if (request.isForMainFrame()) {
                onReceivedError(view,
                        error.getErrorCode(), error.getDescription().toString(),
                        request.getUrl().toString());
            }
        }
    }

    public void setAsDefaultSmsApp() {
        Intent intent = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            RoleManager roleManager = getSystemService(RoleManager.class);
            if (roleManager.isRoleAvailable(RoleManager.ROLE_SMS) && !roleManager.isRoleHeld(RoleManager.ROLE_SMS)) {
                intent = roleManager.createRequestRoleIntent(RoleManager.ROLE_SMS);
            }
        } else {
            intent = new Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT);
        }

        if (intent != null) {
            intent.putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, mPackageName);
            makeDefaultAppDialog.launch(intent);
        }
    }

    private class MyWebChromeClient extends WebChromeClient {
        public boolean onShowFileChooser(WebView mWebView, ValueCallback<Uri[]> filePathCallback, WebChromeClient.FileChooserParams fileChooserParams) {
            if (mUploadMessage != null) {
                mUploadMessage.onReceiveValue(null);
                mUploadMessage = null;
            }

            mUploadMessage = filePathCallback;

            Intent intent = fileChooserParams.createIntent();
            intent.setType("*/*");
            try {
                selectFileDialog.launch(intent);
            } catch (ActivityNotFoundException e) {
                mUploadMessage = null;
                showErrorToast(getString(R.string.error_no_application_found));
                return false;
            }
            return true;
        }
    }
}

package org.rbsoft.smsgateway.models;

import android.content.Context;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import org.rbsoft.smsgateway.services.MyWebService;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import io.objectbox.Box;
import io.objectbox.BoxStore;
import io.objectbox.annotation.Entity;
import io.objectbox.annotation.Id;
import io.objectbox.annotation.Transient;
import retrofit2.Response;

import static org.rbsoft.smsgateway.others.Common.TAG;
import static org.rbsoft.smsgateway.others.Common.getAndroidId;
import static org.rbsoft.smsgateway.others.Common.getBoxStore;
import static org.rbsoft.smsgateway.others.Common.getGsonStatusReport;
import static org.rbsoft.smsgateway.others.Common.getWebService;

@Entity
public class ReceivedMessage {

    @Transient
    private static Box<ReceivedMessage> box;
    @SerializedName("number")
    @Expose
    private String number;
    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("simSlot")
    @Expose
    private Integer simSlot;
    private Integer userID;
    @SerializedName("sentDate")
    @Expose
    private Date sentDate;
    @SerializedName("receivedDate")
    @Expose
    private Date receivedDate;
    @Id
    private Long iD;
    private boolean delivered;
    private String server;

    public static Box<ReceivedMessage> getBox(Context context) {
        if (box == null) {
            BoxStore boxStore = getBoxStore(context);
            box = boxStore.boxFor(ReceivedMessage.class);
        }
        return box;
    }

    public static boolean send(Context context, String server, int userId) {
        List<ReceivedMessage> messages = ReceivedMessage.getBox(context).query().equal(ReceivedMessage_.server, server).equal(ReceivedMessage_.userID, userId).equal(ReceivedMessage_.delivered, false).build().find();
        if (messages.size() > 0) {
            MyWebService myWebService = getWebService(server);
            Gson gson = getGsonStatusReport();
            retrofit2.Call<JsonResponse> call = myWebService.sendReceivedMessage(getAndroidId(context), userId, gson.toJson(messages));
            try {
                Response<JsonResponse> response = call.execute();
                if (response.isSuccessful()) {
                    JsonResponse jsonResponse = response.body();
                    if (jsonResponse != null) {
                        if (jsonResponse.getSuccess()) {
                            getBoxStore(context).runInTx(() -> {
                                for (ReceivedMessage message : messages) {
                                    message.setDelivered(true);
                                    ReceivedMessage.getBox(context).put(message);
                                }
                            });
                            Log.d(TAG, String.format("sendReceivedMessage : Successfully sent %d received messages.", messages.size()));
                            return true;
                        } else {
                            Log.d(TAG, String.format("sendReceivedMessage : %s", jsonResponse.getError().getMessage()));
                        }
                    }
                } else {
                    Log.d(TAG, String.format("sendReceivedMessage : %d %s", response.code(), response.message()));
                }
            } catch (IOException e) {
                e.printStackTrace();
                Log.d(TAG, String.format("sendReceivedMessage : %s", e.getMessage()));
            }
            return false;
        }
        return true;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Integer getSimSlot() {
        return simSlot;
    }

    public void setSimSlot(Integer simSlot) {
        this.simSlot = simSlot;
    }

    public Integer getUserID() {
        return userID;
    }

    public void setUserID(Integer userID) {
        this.userID = userID;
    }

    public Date getSentDate() {
        return sentDate;
    }

    public void setSentDate(Date sentDate) {
        this.sentDate = sentDate;
    }

    public Date getReceivedDate() {
        return receivedDate;
    }

    public void setReceivedDate(Date receivedDate) {
        this.receivedDate = receivedDate;
    }

    public Long getID() {
        return iD;
    }

    public void setID(Long iD) {
        this.iD = iD;
    }

    public boolean isDelivered() {
        return delivered;
    }

    public void setDelivered(boolean delivered) {
        this.delivered = delivered;
    }

    public String getServer() {
        return server;
    }

    public void setServer(String server) {
        this.server = server;
    }
}

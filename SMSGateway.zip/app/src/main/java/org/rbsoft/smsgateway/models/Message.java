package org.rbsoft.smsgateway.models;

import static android.telephony.SubscriptionManager.INVALID_SUBSCRIPTION_ID;

import android.Manifest;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.util.ArrayMap;
import android.util.Log;
import android.util.SparseIntArray;
import android.webkit.URLUtil;

import androidx.core.app.ActivityCompat;

import com.google.gson.Gson;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.klinker.android.send_message.Settings;
import com.klinker.android.send_message.Transaction;

import org.rbsoft.smsgateway.receivers.DeliveryReceiver;
import org.rbsoft.smsgateway.receivers.SentReceiver;
import org.rbsoft.smsgateway.services.MyWebService;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import io.objectbox.Box;
import io.objectbox.BoxStore;
import io.objectbox.annotation.Entity;
import io.objectbox.annotation.Id;
import io.objectbox.annotation.Transient;
import okhttp3.Request;
import retrofit2.Response;

import static org.rbsoft.smsgateway.others.Common.*;

@Entity
public class Message {

    @SerializedName("number")
    @Expose(serialize = false)
    private String number;
    @SerializedName("message")
    @Expose(serialize = false)
    private String message;
    @Transient
    private static final ArrayMap<String, Bitmap> bitmaps = new ArrayMap<>();
    @SerializedName("attachments")
    @Expose(serialize = false)
    private String attachments;
    @SerializedName("deviceID")
    @Expose(serialize = false)
    private Integer deviceID;
    @SerializedName("userID")
    @Expose(serialize = false)
    private Integer userID;
    @SerializedName("simSlot")
    @Expose
    private Integer simSlot;
    @SerializedName("groupID")
    @Expose(serialize = false)
    private String groupID;
    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("ID")
    @Expose
    @Id(assignable = true)
    public Long iD;
    @SerializedName("sentDate")
    @Expose(serialize = false)
    private Date sentDate;
    @SerializedName("deliveredDate")
    @Expose
    private Date deliveredDate;
    @SerializedName("resultCode")
    @Expose
    private Integer resultCode;
    @SerializedName("errorCode")
    @Expose
    private Integer errorCode;

    private boolean delivered;

    private String server;

    private Integer pendingParts;

    @Transient
    public static int count;
    @Transient
    private static Box<Message> box;
    @Transient
    private static SparseIntArray subscriptionIds;
    @SerializedName("type")
    @Expose(serialize = false)
    private String type;

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getAttachments() {
        return attachments;
    }

    public void setAttachments(String attachments) {
        this.attachments = attachments;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getDeviceID() {
        return deviceID;
    }

    public void setDeviceID(Integer deviceID) {
        this.deviceID = deviceID;
    }

    public Integer getUserID() {
        return userID;
    }

    public void setUserID(Integer userID) {
        this.userID = userID;
    }

    public String getGroupID() {
        return groupID;
    }

    public void setGroupID(String groupID) {
        this.groupID = groupID;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getResultCode() {
        return resultCode;
    }

    public void setResultCode(Integer resultCode) {
        this.resultCode = resultCode;
    }

    public Integer getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(Integer errorCode) {
        this.errorCode = errorCode;
    }

    public Date getSentDate() {
        return sentDate;
    }

    public void setSentDate(Date sentDate) {
        this.sentDate = sentDate;
    }

    public Date getDeliveredDate() {
        return deliveredDate;
    }

    public void setDeliveredDate(Date deliveredDate) {
        this.deliveredDate = deliveredDate;
    }

    public long getID() {
        return iD;
    }

    public void setID(Long iD) {
        this.iD = iD;
    }

    public String getServer() {
        return server;
    }

    public void setServer(String server) {
        this.server = server;
    }

    public Integer getPendingParts() {
        return pendingParts;
    }

    public void setPendingParts(Integer pendingParts) {
        this.pendingParts = pendingParts;
    }

    public boolean isDelivered() {
        return delivered;
    }

    public void setDelivered(boolean delivered) {
        this.delivered = delivered;
    }

    public Integer getSimSlot() {
        return simSlot;
    }

    public void setSimSlot(Integer simSlot) {
        this.simSlot = simSlot;
    }

    public void send(Context context, boolean requireDeliveryReport) {
        try {
            Integer subscriptionId = getSubscriptionId(context);

            if (Objects.equals(this.getType(), "mms")) {
                Settings settings = new Settings();
                settings.setUseSystemSending(true);
                settings.setDeliveryReports(requireDeliveryReport);
                settings.setSubscriptionId(subscriptionId);
                settings.setSendLongAsMms(true);
                settings.setSendLongAsMmsAfter(0);

                com.klinker.android.send_message.Message message = new com.klinker.android.send_message.Message(this.getMessage(), this.getNumber());

                Bitmap[] images = new Bitmap[0];
                if (this.getAttachments() != null) {
                    String[] attachments = this.getAttachments().trim().split("\\s*,\\s*");
                    images = new Bitmap[attachments.length];
                    for (int i = 0; i < attachments.length; i++) {
                        String attachment = attachments[i];
                        if (bitmaps.containsKey(attachment)) {
                            images[i] = bitmaps.get(attachment);
                        } else {
                            String url;
                            if (URLUtil.isHttpUrl(attachment) || URLUtil.isHttpsUrl(attachment)) {
                                url = attachment;
                            } else {
                                url = String.format("%s%s", this.getServer(), attachment);
                            }
                            Log.d(TAG, String.format("Downloading image from \"%s\".", url));
                            Request request = new Request.Builder().url(url).build();
                            okhttp3.Response response = getOkHttpClient().newCall(request).execute();
                            if (response.isSuccessful()) {
                                images[i] = BitmapFactory.decodeStream(response.body().byteStream());
                                Log.d(TAG, String.format("Successfully downloaded image from \"%s\".", url));
                                bitmaps.put(attachment, images[i]);
                            } else {
                                throw new Exception(String.format("Unable to download attachment : %d %s", response.code(), response.message()));
                            }
                        }
                    }
                }

                message.setImages(images);

                Bundle bundle = new Bundle();
                bundle.putLong("id", this.getID());
                Transaction transaction = new Transaction(context, settings);
                getBox(context).put(this);
                transaction.sendNewMessage(message, Transaction.NO_THREAD_ID, bundle, bundle);
            } else {
                SmsManager smsManager;

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                    if (subscriptionId == null) {
                        int defaultSubId = SmsManager.getDefaultSmsSubscriptionId();
                        if (defaultSubId == INVALID_SUBSCRIPTION_ID) {
                            throw new Exception();
                        }
                        smsManager = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ?
                                context.getSystemService(SmsManager.class).createForSubscriptionId(defaultSubId) :
                                SmsManager.getSmsManagerForSubscriptionId(defaultSubId);
                    } else {
                        smsManager = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ?
                                context.getSystemService(SmsManager.class).createForSubscriptionId(subscriptionId) :
                                SmsManager.getSmsManagerForSubscriptionId(subscriptionId);
                    }
                } else {
                    smsManager = SmsManager.getDefault();
                }

                ArrayList<String> messages = smsManager.divideMessage(message);

                Intent intentSent = new Intent(context.getApplicationContext(), SentReceiver.class);
                intentSent.setAction(MESSAGE_SENT_ACTION);
                intentSent.putExtra(EXTRA_MESSAGE_ID, this.getID());

                int messageCount = messages.size();
                ArrayList<PendingIntent> sentIntents = new ArrayList<>(messageCount);
                ArrayList<PendingIntent> deliveryIntents = null;
                Intent intentDelivered = null;
                if (requireDeliveryReport) {
                    deliveryIntents = new ArrayList<>(messageCount);
                    intentDelivered = new Intent(context.getApplicationContext(), DeliveryReceiver.class);
                    intentDelivered.setAction(MESSAGE_DELIVERED_ACTION);
                    intentDelivered.putExtra(EXTRA_MESSAGE_ID, this.getID());
                }

                for (int i = 1; i <= messageCount; i++) {
                    count++;
                    PendingIntent sentPendingIntent = PendingIntent.getBroadcast(context.getApplicationContext(), count, intentSent, PendingIntent.FLAG_ONE_SHOT);
                    sentIntents.add(sentPendingIntent);
                    if (requireDeliveryReport) {
                        if (i == messageCount) {
                            PendingIntent deliveredPendingIntent = PendingIntent.getBroadcast(context.getApplicationContext(), count, intentDelivered, PendingIntent.FLAG_ONE_SHOT);
                            deliveryIntents.add(deliveredPendingIntent);
                        } else {
                            deliveryIntents.add(null);
                        }
                    }
                }

                this.setPendingParts(messageCount);
                getBox(context).put(this);
                smsManager.sendMultipartTextMessage(number, null, messages, sentIntents, deliveryIntents);
            }
        } catch (Exception e) {
            Log.d(TAG, e.getMessage());
            this.setStatus("Failed");
            this.setDeliveredDate(new Date());
            getBox(context).put(this);
        }
    }

    public static boolean sendStatusReport(Context context, String server, List<Message> messages, boolean save) {
        MyWebService myWebService = getWebService(server);
        Gson gson = getGsonStatusReport();
        retrofit2.Call<JsonResponse> call = myWebService.sendStatusReport(gson.toJson(messages));
        try {
            Response<JsonResponse> response = call.execute();
            if (response.isSuccessful()) {
                JsonResponse jsonResponse = response.body();
                if (jsonResponse != null) {
                    if (jsonResponse.getSuccess()) {
                        if (save) {
                            getBoxStore(context).runInTx(() -> {
                                for (Message message : messages) {
                                    message.setDelivered(true);
                                    box.put(message);
                                }
                            });
                        }
                        return true;
                    } else {
                        Log.d(TAG, String.format("sendStatusReport : %s", jsonResponse.getError().getMessage()));
                    }
                }
            } else {
                Log.d(TAG, String.format("sendStatusReport : %d %s", response.code(), response.message()));
            }
        } catch (IOException e) {
            e.printStackTrace();
            Log.d(TAG, String.format("sendStatusReport : %s", e.getMessage()));
        }
        return false;
    }

    public static Box<Message> getBox(Context context) {
        if (box == null) {
            BoxStore boxStore = getBoxStore(context);
            box = boxStore.boxFor(Message.class);
        }
        return box;
    }

    public Integer getSubscriptionId(Context context) {
        if (subscriptionIds == null) {
            subscriptionIds = new SparseIntArray();
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP_MR1) {
                SubscriptionManager subscriptionManager = (SubscriptionManager) context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
                if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                    List<SubscriptionInfo> subscriptionInfoList = subscriptionManager.getActiveSubscriptionInfoList();
                    for (SubscriptionInfo subscriptionInfo : subscriptionInfoList) {
                        subscriptionIds.put(subscriptionInfo.getSimSlotIndex(), subscriptionInfo.getSubscriptionId());
                    }
                }
            }
        }

        Integer subscriptionId = null;
        if (this.getSimSlot() != null) {
            if (subscriptionIds.indexOfKey(this.getSimSlot()) >= 0) {
                subscriptionId = subscriptionIds.get(this.getSimSlot());
                Log.d(TAG, String.format("The subscription Id of sim slot #%1$d is %2$d.", this.getSimSlot(), subscriptionId));
            } else {
                this.setSimSlot(null);
            }
        }

        return subscriptionId;
    }

    public boolean sendStatus(Context context) {
        List<Message> messages = new ArrayList<>();
        messages.add(this);
        return sendStatusReport(context, this.getServer(), messages, true);
    }
}
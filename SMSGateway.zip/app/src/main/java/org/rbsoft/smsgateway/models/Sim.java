package org.rbsoft.smsgateway.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Sim {
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("carrier")
    @Expose
    private String carrier;
    @SerializedName("country")
    @Expose
    private String country;
    @SerializedName("iccID")
    @Expose
    private String iccID;
    @SerializedName("number")
    @Expose
    private String number;
    @SerializedName("slot")
    @Expose
    private Integer slot;
    @SerializedName("enabled")
    @Expose
    private boolean enabled;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCarrier() {
        return carrier;
    }

    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getIccID() {
        return iccID;
    }

    public void setIccID(String iccID) {
        this.iccID = iccID;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public Integer getSlot() {
        return slot;
    }

    public void setSlot(Integer slot) {
        this.slot = slot;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
}

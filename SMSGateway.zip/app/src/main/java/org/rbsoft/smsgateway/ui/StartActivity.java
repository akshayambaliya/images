package org.rbsoft.smsgateway.ui;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.pm.PackageInfoCompat;

import android.os.Bundle;

import org.rbsoft.smsgateway.R;

import static org.rbsoft.smsgateway.models.Update.PREF_LATEST_VERSION_CODE;
import static org.rbsoft.smsgateway.models.Update.PREF_LATEST_VERSION_URL;
import static org.rbsoft.smsgateway.others.Common.PREF_SETTINGS;
import static org.rbsoft.smsgateway.others.Common.PREF_SKIP_VERSION_CODE;
import static org.rbsoft.smsgateway.others.Common.PREF_USER_ID;
import static org.rbsoft.smsgateway.others.Common.isRunningMIUI;

public class StartActivity extends AppCompatActivity {

    private static final String[] PERMISSIONS = new String[]{
            Manifest.permission.SEND_SMS,
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.RECEIVE_MMS,
            Manifest.permission.READ_SMS,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };
    SharedPreferences mSharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mSharedPreferences = getSharedPreferences(PREF_SETTINGS, Context.MODE_PRIVATE);
        setContentView(R.layout.activity_start);
        try {
            PackageInfo packageInfo = this.getPackageManager().getPackageInfo(this.getPackageName(), 0);
            long versionCode = mSharedPreferences.getLong(PREF_LATEST_VERSION_CODE, 1);
            String url = mSharedPreferences.getString(PREF_LATEST_VERSION_URL, "https://rbsoft.org/downloads/sms-gateway/sms-gateway.apk");
            if (mSharedPreferences.getLong(PREF_SKIP_VERSION_CODE, 1) != versionCode && versionCode > PackageInfoCompat.getLongVersionCode(packageInfo)) {
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
                alertDialog.setMessage(R.string.dialog_update_available_message);
                alertDialog.setTitle(R.string.dialog_update_available_title);
                alertDialog.setPositiveButton(R.string.button_yes, (dialog, which) -> {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    try {
                        startActivity(intent);
                        finish();
                    } catch (ActivityNotFoundException e) {
                        new AlertDialog.Builder(this)
                                .setMessage(R.string.error_no_application_found_url)
                                .setCancelable(false)
                                .setPositiveButton(R.string.button_ok, (dialogInterface, i) -> {
                                    start();
                                })
                                .create()
                                .show();
                    }
                });
                alertDialog.setNegativeButton(R.string.button_skip, (dialog, which) -> {
                    SharedPreferences.Editor editor = mSharedPreferences.edit();
                    editor.putLong(PREF_SKIP_VERSION_CODE, versionCode);
                    editor.apply();
                    start();
                });
                alertDialog.setNeutralButton(R.string.button_no, (dialog, which) -> start());
                alertDialog.setCancelable(false);
                alertDialog.create().show();
            } else {
                start();
            }
        } catch (PackageManager.NameNotFoundException e) {
            start();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        boolean permissionsGranted;
        permissionsGranted = grantResults.length > 0;
        for (int result : grantResults) {
            permissionsGranted = permissionsGranted && result == PackageManager.PERMISSION_GRANTED;
        }
        if (permissionsGranted) {
            if (isIgnoringBatteryOptimizations()) {
                init();
            }
        } else {
            finishAndRemoveTask();
        }
    }

    ActivityResultLauncher<Intent> batteryOptimizationDialog = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    init();
                } else {
                    finishAndRemoveTask();
                }
            });

    @TargetApi(Build.VERSION_CODES.M)
    private boolean isIgnoringBatteryOptimizations() {
        if (isRunningMIUI(this)) {
            return true;
        }

        String packageName = getPackageName();
        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        if (powerManager.isIgnoringBatteryOptimizations(packageName)) {
            return true;
        } else {
            Intent intent = new Intent();
            intent.setAction(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            intent.setData(Uri.parse("package:" + packageName));

            try {
                batteryOptimizationDialog.launch(intent);
                return false;
            } catch (ActivityNotFoundException e) {
                return true;
            }
        }
    }

    private void start() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            for (String permission : PERMISSIONS) {
                if (ActivityCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(PERMISSIONS, 0);
                    return;
                }
            }
            if (!isIgnoringBatteryOptimizations()) {
                return;
            }
        }

        init();
    }

    private void init() {
        Intent intent;

        if (mSharedPreferences.getInt(PREF_USER_ID, 0) != 0) {
            intent = new Intent(getApplicationContext(), MainActivity.class);
        } else {
            intent = new Intent(getApplicationContext(), LoginActivity.class);
        }

        startActivity(intent);
        finish();
    }
}
package org.rbsoft.smsgateway.others;

import android.Manifest;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Build;
import android.os.PersistableBundle;
import android.provider.Settings;

import androidx.core.app.ActivityCompat;

import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.rbsoft.smsgateway.BuildConfig;
import org.rbsoft.smsgateway.models.MyObjectBox;
import org.rbsoft.smsgateway.models.Sim;
import org.rbsoft.smsgateway.services.*;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import io.objectbox.BoxStore;
import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Common {

    public static final String PREF_SETTINGS = "PREF_SETTINGS";
    public static final String PREF_SERVER = "PREF_SERVER";
    public static final String PREF_SENDER_ID = "PREF_SENDER_ID";
    public static final String PREF_USER_ID = "PREF_USER_ID";
    public static final String PREF_MESSAGES_SEND = "PREF_MESSAGES_SEND";
    public static final String PREF_READ_RECEIVED = "PREF_READ_RECEIVED";
    public static final String PREF_CHECK_AUTO_START_MANAGERS = "PREF_CHECK_AUTO_START_MANAGERS";
    public static final String PREF_CHECK_BATTERY_SAVERS = "PREF_CHECK_BATTERY_SAVERS";
    public static final String PREF_CHECK_DEFAULT_APP = "PREF_CHECK_DEFAULT_APP";
    public static final String PREF_SERVICE_RUNNING = "PREF_SERVICE_RUNNING";
    public static final String PREF_SKIP_VERSION_CODE = "PREF_SKIP_VERSION_CODE";

    public static final String EXTRA_MESSAGE_ID = "EXTRA_MESSAGE_ID";
    public static final String EXTRA_MIN_DELAY = "EXTRA_MIN_DELAY";
    public static final String EXTRA_MAX_DELAY = "EXTRA_MAX_DELAY";
    public static final String EXTRA_GROUP_ID = "EXTRA_GROUP_ID";
    public static final String EXTRA_REPORT_DELIVERY = "EXTRA_REPORT_DELIVERY";
    public static final String EXTRA_SLEEP_TIME = "EXTRA_SLEEP_TIME";
    public static final String EXTRA_SERVER = "EXTRA_SERVER";
    public static final String EXTRA_STATUS = "EXTRA_STATUS";
    public static final String EXTRA_RESULT_CODE = "EXTRA_RESULT_CODE";
    public static final String EXTRA_ERROR_CODE = "EXTRA_ERROR_CODE";
    public static final String EXTRA_SENT_TIME = "EXTRA_SENT_TIME";
    public static final String EXTRA_TIME = "EXTRA_TIME";
    public static final String EXTRA_USER_ID = "EXTRA_USER_ID";
    public static final String EXTRA_NUMBER = "EXTRA_NUMBER";
    public static final String EXTRA_MESSAGE = "EXTRA_MESSAGE";
    public static final String EXTRA_SIM_SLOT = "EXTRA_SIM_SLOT";

    public static final String MESSAGE_SENT_ACTION = "MESSAGE_SENT";
    public static final String MESSAGE_DELIVERED_ACTION = "MESSAGE_DELIVERED";

    public static final String BUNDLE_SERVER = "BUNDLE_SERVER";
    public static final String BUNDLE_USER_ID = "BUNDLE_USER_ID";
    public static final int RECEIVER_JOB_ID = 26072017;
    public static final int STATUS_REPORTER_JOB_ID = 201960;

    public static final String TAG = "SMS_GATEWAY";

    private volatile static BoxStore sBoxStore = null;

    private volatile static OkHttpClient sOkHttpClient = null;

    private volatile static GsonConverterFactory sGsonConverterFactory = null;

    private volatile static Gson sGsonStatusReport = null;

    public static String getAndroidId(Context context) {
        return Settings.Secure.getString(context.getContentResolver(),
                Settings.Secure.ANDROID_ID);
    }

    public static synchronized Gson getGsonStatusReport() {
        if (sGsonStatusReport == null) {
            sGsonStatusReport = new GsonBuilder()
                    .setDateFormat("yyyy-MM-dd'T'HH:mm:ssZ")
                    .excludeFieldsWithoutExposeAnnotation()
                    .create();
        }
        return sGsonStatusReport;
    }

    public static synchronized BoxStore getBoxStore(Context context) {
        if (sBoxStore == null) {
            sBoxStore = MyObjectBox.builder().name("sms-gateway-" + BuildConfig.VERSION_CODE)
                    .androidContext(context.getApplicationContext()).build();
        }
        return sBoxStore;
    }

    public static synchronized OkHttpClient getOkHttpClient() {
        if (sOkHttpClient == null) {
            OkHttpClient.Builder okHttpClientBuilder = new OkHttpClient.Builder()
                    .retryOnConnectionFailure(true)
                    .readTimeout(20, TimeUnit.SECONDS)
                    .connectTimeout(20, TimeUnit.SECONDS);

            // Create a trust manager that does not validate certificate chains
            final TrustManager[] trustAllCerts = new TrustManager[]{
                    new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType) {
                        }

                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType) {
                        }

                        @Override
                        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                            return new java.security.cert.X509Certificate[]{};
                        }
                    }
            };

            try {
                // Install the all-trusting trust manager
                final SSLContext sslContext = SSLContext.getInstance("SSL");
                sslContext.init(null, trustAllCerts, new java.security.SecureRandom());

                // Create an ssl socket factory with our all-trusting manager
                final SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

                okHttpClientBuilder.sslSocketFactory(sslSocketFactory, (X509TrustManager) trustAllCerts[0]);
                okHttpClientBuilder.hostnameVerifier((hostname, session) -> true);
            } catch (NoSuchAlgorithmException | KeyManagementException e) {
                e.printStackTrace();
            }

            sOkHttpClient = okHttpClientBuilder.build();
        }
        return sOkHttpClient;
    }

    public static synchronized MyWebService getWebService(String server) {
        if (sGsonConverterFactory == null) {
            Gson gson = new GsonBuilder()
                    .setDateFormat("yyyy-MM-dd HH:mm:ss")
                    .create();
            sGsonConverterFactory = GsonConverterFactory.create(gson);
        }
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(server)
                .client(getOkHttpClient())
                .addConverterFactory(sGsonConverterFactory)
                .build();
        return retrofit.create(MyWebService.class);
    }

    public static boolean scheduleJob(Context context, int jobId, String className, PersistableBundle extras) {
        JobScheduler jobScheduler = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        for (JobInfo jobInfo : jobScheduler.getAllPendingJobs()) {
            if (jobInfo.getId() == jobId) {
                return true;
            }
        }

        JobInfo.Builder builder = new JobInfo.Builder(jobId,
                new ComponentName(context.getPackageName(), className))
                .setExtras(extras)
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setRequiresCharging(false)
                .setPeriodic(30 * 60 * 1000)
                .setPersisted(true);
        int result = jobScheduler.schedule(builder.build());
        return result == JobScheduler.RESULT_SUCCESS;
    }

    public static String getAllSims(Context context) {
        List<Sim> sims = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            SubscriptionManager subscriptionManager = (SubscriptionManager) context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
            int totalSimSlots = subscriptionManager.getActiveSubscriptionInfoCountMax();
            for (int i = 0; i < totalSimSlots; i++) {
                if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                    SubscriptionInfo subscriptionInfo = subscriptionManager.getActiveSubscriptionInfoForSimSlotIndex(i);

                    Sim sim = new Sim();
                    if (subscriptionInfo != null) {
                        if (subscriptionInfo.getDisplayName() != null) {
                            sim.setName(subscriptionInfo.getDisplayName().toString());
                        }
                        if (subscriptionInfo.getCarrierName() != null) {
                            sim.setCarrier(subscriptionInfo.getCarrierName().toString());
                        }
                        sim.setCountry(subscriptionInfo.getCountryIso());
                        sim.setSlot(i);
                        sim.setIccID(subscriptionInfo.getIccId());
                        sim.setNumber(subscriptionInfo.getNumber());
                        sim.setEnabled(true);
                    } else {
                        sim.setEnabled(false);
                        sim.setSlot(i);
                    }
                    sims.add(sim);
                }
            }
        }
        return new Gson().toJson(sims);
    }

    public static boolean isCurrentTimeBetween(String timeRange) {
        if (timeRange != null) {
            String[] values = timeRange.split("-");
            LocalTime from = LocalTime.parse(values[0]);
            LocalTime to = LocalTime.parse(values[1]);
            LocalTime now = LocalTime.now();
            if (to.isAfter(from)) {
                return now.isAfter(from) && now.isBefore(to);
            } else {
                return now.isAfter(from) || now.isBefore(to);
            }
        }
        return false;
    }

    public static long getTimestampAfter(String timeRange) {
        String[] values = timeRange.split("-");
        LocalTime to = LocalTime.parse(values[1]);
        LocalTime now = LocalTime.now();
        long diff;
        if (to.isAfter(now)) {
            diff = ChronoUnit.MILLIS.between(now, to);
        } else {
            diff = ChronoUnit.MILLIS.between(now, LocalTime.MAX) + ChronoUnit.MILLIS.between(LocalTime.MIN, to);
        }
        return new Date().getTime() + diff;
    }

    public static boolean isRunningMIUI(Context context) {
        Intent miuiIntent = new Intent("miui.intent.action.HIDDEN_APPS_CONFIG_ACTIVITY");
        List<ResolveInfo> activities = context.getPackageManager().queryIntentActivities(miuiIntent, PackageManager.MATCH_DEFAULT_ONLY);
        return activities.size() > 0;
    }
}

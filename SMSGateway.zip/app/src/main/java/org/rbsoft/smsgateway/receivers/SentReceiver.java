package org.rbsoft.smsgateway.receivers;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.SmsManager;
import android.util.Log;

import org.rbsoft.smsgateway.services.StatusReporterService;

import java.util.Date;
import java.util.Objects;

import static org.rbsoft.smsgateway.others.Common.EXTRA_MESSAGE_ID;
import static org.rbsoft.smsgateway.others.Common.MESSAGE_SENT_ACTION;
import static org.rbsoft.smsgateway.others.Common.TAG;

public class SentReceiver extends BroadcastReceiver {

    // Defined by platform, but no constant provided. See docs for SmsManager.sendTextMessage.
    public static final String EXTRA_ERROR_CODE = "errorCode";
    public static final String EXTRA_NO_DEFAULT = "noDefault";

    public static final int NO_ERROR_CODE = -1;

    @Override
    public void onReceive(Context context, Intent intent) {
        if (Objects.equals(intent.getAction(), MESSAGE_SENT_ACTION)) {
            Long id = intent.getLongExtra(EXTRA_MESSAGE_ID, 0);
            int errorCode = intent.getIntExtra(EXTRA_ERROR_CODE, NO_ERROR_CODE);

            String status;
            int resultCode = getResultCode();
            switch (resultCode) {
                case Activity.RESULT_OK:
                    status = "Sent";
                    break;
                /*
                case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
                    boolean noDefault = intent.getBooleanExtra(EXTRA_NO_DEFAULT, false);
                    if (noDefault) {
                        Log.d(TAG, "Failed sending the SMS message because no suitable default subscription could be found.");
                    }
                    break;
                */
                default:
                    status = "Failed";
                    break;
            }
            StatusReporterService.enqueueWork(context, id, status, resultCode, errorCode, new Date());
            Log.d(TAG, String.format("SentReceiver : Message #%d %s with resultCode %d and errorCode %d", id, status, resultCode, errorCode));
        }
    }
}
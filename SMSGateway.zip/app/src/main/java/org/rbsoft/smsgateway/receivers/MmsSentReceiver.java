package org.rbsoft.smsgateway.receivers;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import org.rbsoft.smsgateway.services.StatusReporterService;

import java.util.Date;

import static org.rbsoft.smsgateway.others.Common.TAG;

public class MmsSentReceiver extends com.klinker.android.send_message.MmsSentReceiver {
    public void onMessageStatusUpdated(Context context, Intent intent, int resultCode) {
        Bundle bundle = intent.getBundleExtra(SENT_MMS_BUNDLE);
        Long id = bundle.getLong("id");

        String status;
        if (resultCode == Activity.RESULT_OK) {
            status = "Sent";
        } else {
            status = "Failed";
        }

        StatusReporterService.enqueueWork(context, id, status, resultCode, -1, new Date());
        Log.d(TAG, String.format("SentReceiver : MMS Message #%d %s with resultCode %d", id, status, resultCode));
    }
}
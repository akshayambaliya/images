package org.rbsoft.smsgateway.dummies;

import android.app.Activity;

public class ComposeSmsActivity extends Activity {
}

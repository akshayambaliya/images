package org.rbsoft.smsgateway.receivers;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import org.rbsoft.smsgateway.services.StatusReporterService;

import java.util.Date;
import java.util.Objects;

import static org.rbsoft.smsgateway.others.Common.*;

public class DeliveryReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (Objects.equals(intent.getAction(), MESSAGE_DELIVERED_ACTION)) {
            Long id = intent.getLongExtra(EXTRA_MESSAGE_ID, 0);

            String status = null;
            int resultCode = getResultCode();
            switch (resultCode) {
                case Activity.RESULT_OK:
                    status = "Delivered";
                    break;
                case Activity.RESULT_CANCELED:
                    status = "Failed";
                    break;
            }

            if (status != null) {
                StatusReporterService.enqueueWork(context, id, status, resultCode, -1, new Date());
            }

            Log.d(TAG, String.format("DeliveryReceiver : Message #%d %s with resultCode %d", id, status, resultCode));
        }
    }
}

package org.rbsoft.smsgateway.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.Date;

public class User {

    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("email")
    @Expose
    private String email;
    @SerializedName("password")
    @Expose
    private String password;
    @SerializedName("isAdmin")
    @Expose
    private Integer isAdmin;
    @SerializedName("primaryDeviceID")
    @Expose
    private Integer primaryDeviceID;
    @SerializedName("delay")
    @Expose
    private String delay;
    @SerializedName("reportDelivery")
    @Expose
    private Integer reportDelivery;
    @SerializedName("sleepTime")
    @Expose
    private String sleepTime;
    @SerializedName("dateAdded")
    @Expose
    private Date dateAdded;
    @SerializedName("ID")
    @Expose
    private Integer iD;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Integer getIsAdmin() {
        return isAdmin;
    }

    public void setIsAdmin(Integer isAdmin) {
        this.isAdmin = isAdmin;
    }

    public Integer getPrimaryDeviceID() {
        return primaryDeviceID;
    }

    public void setPrimaryDeviceID(Integer primaryDeviceID) {
        this.primaryDeviceID = primaryDeviceID;
    }

    public String getDelay() {
        return delay;
    }

    public void setDelay(String delay) {
        this.delay = delay;
    }

    public Date getDateAdded() {
        return dateAdded;
    }

    public void setDateAdded(Date dateAdded) {
        this.dateAdded = dateAdded;
    }

    public Integer getID() {
        return iD;
    }

    public void setID(Integer iD) {
        this.iD = iD;
    }

    public Integer getReportDelivery() {
        return reportDelivery;
    }

    public void setReportDelivery(Integer reportDelivery) {
        this.reportDelivery = reportDelivery;
    }

    public String getSleepTime() {
        return sleepTime;
    }

    public void setSleepTime(String sleepTime) {
        this.sleepTime = sleepTime;
    }
}
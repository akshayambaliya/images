package org.rbsoft.smsgateway.ui;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.iid.FirebaseInstanceId;
import com.google.gson.JsonSyntaxException;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.jaredrummler.android.device.DeviceName;

import org.json.JSONException;
import org.json.JSONObject;
import org.rbsoft.smsgateway.BuildConfig;
import org.rbsoft.smsgateway.R;
import org.rbsoft.smsgateway.models.*;
import org.rbsoft.smsgateway.services.MyWebService;

import java.io.EOFException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.annotation.Nonnull;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static org.rbsoft.smsgateway.others.Common.*;

/**
 * A login screen that offers login via email/password.
 */
public class LoginActivity extends AppCompatActivity {

    // UI references.
    private EditText mServerView;
    private EditText mEmailView;
    private EditText mPasswordView;
    private View mProgressView;
    private View mLoginFormView;

    private SharedPreferences mSettings;

    private boolean mInProgress;

    String mServer;
    String mApiKey;
    String mEmail;
    String mPassword;
    String mSenderId;
    int mUserId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        mSettings = getSharedPreferences(PREF_SETTINGS, Context.MODE_PRIVATE);

        if (mSettings.getInt(PREF_USER_ID, 0) != 0) {
            startActivity(new Intent(getApplicationContext(), MainActivity.class));
            finish();
        }

        // Set up the login form.
        mEmailView = findViewById(R.id.email);

        mServerView = findViewById(R.id.server);
        if (TextUtils.isEmpty(BuildConfig.SERVER_URL)) {
            String server = mSettings.getString(PREF_SERVER, "");
            if (!TextUtils.isEmpty(server)) {
                mServerView.setText(server);
            }
        } else {
            mServer = BuildConfig.SERVER_URL;
            mServerView.setText(mServer);
            mServerView.setVisibility(View.GONE);
            LinearLayout serverInputView = findViewById(R.id.server_input_view);
            serverInputView.setVisibility(View.GONE);
        }

        mPasswordView = findViewById(R.id.password);
        mPasswordView.setOnEditorActionListener((TextView textView, int id, KeyEvent keyEvent) -> {
            if (id == EditorInfo.IME_ACTION_DONE || id == EditorInfo.IME_NULL) {
                attemptLogin(textView);
                return true;
            }
            return false;
        });

        Button mSignInButton = findViewById(R.id.sign_in_button);
        mSignInButton.setOnClickListener(this::attemptLogin);

        Button mScanQRCodeButton = findViewById(R.id.sign_in_using_qr_code_button);
        mScanQRCodeButton.setOnClickListener(view -> {
            new IntentIntegrator(this).setOrientationLocked(false).setBeepEnabled(false).initiateScan();
        });

        mLoginFormView = findViewById(R.id.login_form);
        mProgressView = findViewById(R.id.login_progress);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null) {
            if (result.getContents() != null) {
                try {
                    Log.d(TAG, String.format("QR Code scan result : %s", result.getContents()));
                    JSONObject jObject = new JSONObject(result.getContents());
                    if (jObject.has("server") && jObject.has("key") && isServerValid(jObject.getString("server")) && isAPIKeyValid(jObject.getString("key"))) {
                        mServer = jObject.getString("server") + "/";
                        mApiKey = jObject.getString("key");
                        registerDevice();
                    } else {
                        Toast.makeText(this, R.string.error_incorrect_qr_code, Toast.LENGTH_LONG).show();
                    }
                } catch (JSONException e) {
                    Toast.makeText(this, R.string.error_incorrect_qr_code, Toast.LENGTH_LONG).show();
                }
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    /**
     * Attempts to sign in or register the account specified by the login form.
     * If there are form errors (invalid email, missing fields, etc.), the
     * errors are presented and no actual login attempt is made.
     */
    private void attemptLogin(View view) {
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
        if (inputMethodManager != null) {
            inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
        if (mInProgress) {
            return;
        }

        // Reset errors.
        mServerView.setError(null);
        mEmailView.setError(null);
        mPasswordView.setError(null);

        // Store values at the time of the login attempt.
        mServer = mServerView.getText().toString().trim();
        mEmail = mEmailView.getText().toString().trim();
        mPassword = mPasswordView.getText().toString();
        mApiKey = null;

        boolean cancel = false;
        View focusView = null;

        // Check for a valid server URL.
        if (TextUtils.isEmpty(mServer)) {
            mServerView.setError(getString(R.string.error_field_required));
            focusView = mServerView;
            cancel = true;
        } else if (!mServer.startsWith("http://") && !mServer.startsWith("https://")) {
            mServerView.setError(getString(R.string.error_server_url_invalid_start));
            focusView = mServerView;
            cancel = true;
        } else if (!isServerValid(mServer)) {
            mServerView.setError(getString(R.string.error_server_url_invalid));
            focusView = mServerView;
            cancel = true;
        } else if (!mServer.endsWith("/")) {
            mServer += "/";
        }

        if (TextUtils.isEmpty(mPassword)) {
            mPasswordView.setError(getString(R.string.error_field_required));
            focusView = mPasswordView;
            cancel = true;
        }
        // Check for a valid password, if the user entered one.
        else if (!isPasswordValid(mPassword)) {
            mPasswordView.setError(getString(R.string.error_invalid_password));
            focusView = mPasswordView;
            cancel = true;
        }

        // Check for a valid email address.
        if (TextUtils.isEmpty(mEmail)) {
            mEmailView.setError(getString(R.string.error_field_required));
            focusView = mEmailView;
            cancel = true;
        } else if (!isEmailValid(mEmail)) {
            mEmailView.setError(getString(R.string.error_invalid_email));
            focusView = mEmailView;
            cancel = true;
        }

        if (cancel) {
            // There was an error; don't attempt login and focus the first
            // form field with an error.
            focusView.requestFocus();
        } else {
            // Show a progress spinner, and kick off a background task to
            // perform the user login attempt.
            registerDevice();
        }
    }

    private boolean isAPIKeyValid(String key) {
        return key != null && key.length() == 40;
    }

    private boolean isEmailValid(String email) {
        return Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    private boolean isServerValid(String server) {
        return Patterns.WEB_URL.matcher(server).matches();
    }

    private boolean isPasswordValid(String password) {
        return password.length() >= 8;
    }

    private void registerDevice() {
        showProgress(true);
        DeviceName.with(this).request((info, error) -> {
            String model = Build.MODEL;
            String androidVersion = Build.VERSION.RELEASE;
            String appVersion = BuildConfig.VERSION_NAME;
            if (error == null) {
                model = info.getName();
            }
            String sims = getAllSims(LoginActivity.this);
            try {
                MyWebService myWebService = getWebService(mServer);
                Call<JsonResponse> call;
                if (mApiKey != null) {
                    call = myWebService.registerDevice(mApiKey, getAndroidId(getApplicationContext()), model, sims, androidVersion, appVersion);
                } else {
                    call = myWebService.registerDevice(mEmail, mPassword, getAndroidId(getApplicationContext()), model, sims, androidVersion, appVersion);
                }
                call.enqueue(new Callback<JsonResponse>() {
                    @Override
                    public void onResponse(@NonNull Call<JsonResponse> call, @NonNull Response<JsonResponse> response) {
                        if (response.isSuccessful()) {
                            JsonResponse jsonResponse = response.body();
                            if (jsonResponse != null) {
                                if (jsonResponse.getSuccess()) {
                                    mSenderId = jsonResponse.getData().getSenderId();
                                    mUserId = jsonResponse.getData().getDevice().getUserID();
                                    ExecutorService executor = Executors.newSingleThreadExecutor();
                                    Handler handler = new Handler(Looper.getMainLooper());
                                    executor.execute(() -> {
                                        try {
                                            String token = FirebaseInstanceId.getInstance().getToken(mSenderId, "FCM");
                                            handler.post(() -> {
                                                MyWebService myWebService = getWebService(mServer);
                                                Call<JsonResponse> registerDeviceCall = myWebService.updateToken(getAndroidId(getApplicationContext()), mUserId, token);
                                                registerDeviceCall.enqueue(new retrofit2.Callback<JsonResponse>() {
                                                    @Override
                                                    public void onResponse(@NonNull Call<JsonResponse> call, @NonNull Response<JsonResponse> response) {
                                                        if (response.isSuccessful()) {
                                                            JsonResponse jsonResponse = response.body();
                                                            if (jsonResponse != null) {
                                                                if (jsonResponse.getSuccess()) {
                                                                    SharedPreferences.Editor editor = mSettings.edit();
                                                                    editor.putString(PREF_SERVER, mServer);
                                                                    editor.putInt(PREF_USER_ID, mUserId);
                                                                    editor.putString(PREF_SENDER_ID, mSenderId);
                                                                    editor.apply();
                                                                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                                                                    startActivity(intent);
                                                                    finish();
                                                                } else {
                                                                    if (jsonResponse.getError().getCode() > 401) {
                                                                        serverError(jsonResponse.getError().getMessage());
                                                                    } else {
                                                                        loginError(jsonResponse.getError().getMessage());
                                                                    }
                                                                }
                                                            }
                                                        } else {
                                                            serverError(String.format("%s %s", response.code(), response.message()));
                                                        }
                                                    }

                                                    @Override
                                                    public void onFailure(@NonNull Call<JsonResponse> call, @NonNull Throwable t) {
                                                        if (t instanceof com.google.gson.stream.MalformedJsonException || t instanceof JsonSyntaxException || t instanceof IllegalStateException || t instanceof EOFException) {
                                                            serverError(getString(R.string.error_invalid_response));
                                                        } else {
                                                            serverError(t.getMessage());
                                                        }
                                                    }
                                                });
                                            });
                                        } catch (Exception e) {
                                            handler.post(() -> serverError(e.getMessage()));
                                        }
                                    });
                                } else {
                                    if (jsonResponse.getError().getCode() > 401) {
                                        serverError(jsonResponse.getError().getMessage());
                                    } else {
                                        loginError(jsonResponse.getError().getMessage());
                                    }
                                }
                            }
                        } else {
                            serverError(String.format("%s %s", response.code(), response.message()));
                        }
                    }

                    @Override
                    public void onFailure(@NonNull Call<JsonResponse> call, @NonNull Throwable t) {
                        if (t instanceof com.google.gson.stream.MalformedJsonException || t instanceof JsonSyntaxException || t instanceof IllegalStateException || t instanceof EOFException) {
                            serverError(getString(R.string.error_invalid_response));
                        } else {
                            serverError(t.getMessage());
                        }
                    }
                });
            } catch (IllegalArgumentException e) {
                serverError(getString(R.string.error_server_url_invalid));
            }
        });
    }

    /**
     * Shows the progress UI and hides the login form.
     */
    private void showProgress(boolean show) {
        // The ViewPropertyAnimator APIs are not available, so simply show
        // and hide the relevant UI components.
        mInProgress = show;
        mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
        mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            moveTaskToBack(true);
            return false;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onConfigurationChanged(@Nonnull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    private void serverError(String message) {
        if (showError(message)) {
            showProgress(false);
            if (mServerView.getVisibility() == View.VISIBLE) {
                mServerView.setError(message);
                mServerView.requestFocus();
            } else {
                Toast.makeText(LoginActivity.this, message, Toast.LENGTH_LONG).show();
            }
        }
    }

    private void loginError(String message) {
        if (showError(message)) {
            mEmailView.setError(message);
            mEmailView.requestFocus();
            mPasswordView.setError(message);
            mPasswordView.requestFocus();
        }
    }

    private boolean showError(String message) {
        showProgress(false);
        if (mApiKey != null) {
            Toast.makeText(LoginActivity.this, message, Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }
}

package org.rbsoft.smsgateway.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;

import org.rbsoft.smsgateway.services.GetCampaignsService;

import java.util.Objects;

import static org.rbsoft.smsgateway.others.Common.PREF_SERVICE_RUNNING;
import static org.rbsoft.smsgateway.others.Common.PREF_SETTINGS;
import static org.rbsoft.smsgateway.others.Common.TAG;

public class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(TAG, intent.getAction());
        if (Objects.equals(intent.getAction(), Intent.ACTION_BOOT_COMPLETED) ||
                Objects.equals(intent.getAction(), "android.intent.action.QUICKBOOT_POWERON") ||
                Objects.equals(intent.getAction(), "com.htc.intent.action.QUICKBOOT_POWERON")) {
            SharedPreferences sharedPreferences = context.getSharedPreferences(PREF_SETTINGS, Context.MODE_PRIVATE);
            if (sharedPreferences.getBoolean(PREF_SERVICE_RUNNING, false)) {
                Intent serviceIntent = new Intent(context.getApplicationContext(), GetCampaignsService.class);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(serviceIntent);
                } else {
                    context.startService(serviceIntent);
                }
            }
        }
    }
}

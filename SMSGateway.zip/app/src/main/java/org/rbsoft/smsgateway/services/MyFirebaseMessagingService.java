package org.rbsoft.smsgateway.services;

import android.app.ActivityManager;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Map;

import static org.rbsoft.smsgateway.others.Common.*;

public class MyFirebaseMessagingService extends FirebaseMessagingService {

    final int UPDATE_TOKEN_JOB_ID = 180388;

    @Override
    public void onNewToken(@NonNull String token) {
        JobInfo.Builder builder = new JobInfo.Builder(UPDATE_TOKEN_JOB_ID,
                new ComponentName(this.getPackageName(),
                        UpdateTokenJob.class.getName()))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setRequiresCharging(false)
                .setPersisted(true);
        JobScheduler jobScheduler = (JobScheduler) this.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (jobScheduler != null) jobScheduler.schedule(builder.build());
    }

    @Override
    public void onMessageReceived(@NonNull RemoteMessage remoteMessage) {
        SharedPreferences settings = getSharedPreferences(PREF_SETTINGS, Context.MODE_PRIVATE);
        boolean running = false;
        ActivityManager activityManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : activityManager.getRunningServices(Integer.MAX_VALUE)) {
            if (GetCampaignsService.class.getName().equals(service.service.getClassName())) {
                running = true;
                break;
            }
        }
        if (!running) {
            final String server = settings.getString(PREF_SERVER, "");
            final int userId = settings.getInt(PREF_USER_ID, 0);
            if (TextUtils.isEmpty(server) || userId == 0) {
                return;
            }
            try {
                // Check if message contains a data payload.
                if (remoteMessage.getData().size() > 0) {
                    Map<String, String> remoteData = remoteMessage.getData();
                    if (remoteData.containsKey("groupId")) {
                        String groupId = remoteData.get("groupId");
                        String delay = null;
                        String sleepTime = null;
                        boolean reportDelivery = false;
                        boolean prioritize = false;
                        if (remoteData.containsKey("delay")) {
                            delay = remoteData.get("delay");
                        }
                        if (remoteData.containsKey("reportDelivery")) {
                            reportDelivery = Integer.parseInt(remoteData.get("reportDelivery")) == 1;
                        }
                        if (remoteData.containsKey("prioritize")) {
                            prioritize = Integer.parseInt(remoteData.get("prioritize")) == 1;
                        }
                        if (remoteData.containsKey("sleepTime")) {
                            sleepTime = remoteData.get("sleepTime");
                        }
                        Log.d(TAG, String.format("Starting SendMessagesService for Message Group #%s.", groupId));
                        SendMessagesService.startActionSendMessages(getApplicationContext(), server, groupId, sleepTime, delay, reportDelivery, prioritize);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}

package org.rbsoft.smsgateway.services;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.os.PersistableBundle;

import static org.rbsoft.smsgateway.others.Common.BUNDLE_SERVER;

public class StatusReporterJob extends JobService {

    @Override
    public boolean onStartJob(JobParameters jobParameters) {
        PersistableBundle persistableBundle = jobParameters.getExtras();
        String server = persistableBundle.getString(BUNDLE_SERVER);
        StatusReporterService.enqueueWork(this, server);
        return false;
    }

    @Override
    public boolean onStopJob(JobParameters jobParameters) {
        return false;
    }
}
package org.rbsoft.smsgateway.services;

import android.content.Context;
import android.content.Intent;

import androidx.annotation.NonNull;
import androidx.core.app.JobIntentService;
import android.util.Log;

import org.rbsoft.smsgateway.models.Message;
import org.rbsoft.smsgateway.models.Message_;

import java.util.Date;
import java.util.List;
import java.util.Objects;

import io.objectbox.Box;

import static org.rbsoft.smsgateway.others.Common.EXTRA_ERROR_CODE;
import static org.rbsoft.smsgateway.others.Common.EXTRA_MESSAGE_ID;
import static org.rbsoft.smsgateway.others.Common.EXTRA_RESULT_CODE;
import static org.rbsoft.smsgateway.others.Common.EXTRA_SERVER;
import static org.rbsoft.smsgateway.others.Common.EXTRA_STATUS;
import static org.rbsoft.smsgateway.others.Common.EXTRA_TIME;
import static org.rbsoft.smsgateway.others.Common.TAG;

public class StatusReporterService extends JobIntentService {

    private static final int JOB_ID = 661006;

    private static final String ACTION_SEND_STATUS = "org.rbsoft.smsgateway.services.action.SEND_STATUS";
    private static final String ACTION_SEND_PERIODIC_STATUS = "org.rbsoft.smsgateway.services.action.SEND_PERIODIC_STATUS";

    public static void enqueueWork(Context context, Long id, String status, int resultCode, int errorCode, @NonNull Date time) {
        JobIntentService.enqueueWork(context.getApplicationContext(), StatusReporterService.class, JOB_ID,
                new Intent()
                        .putExtra(EXTRA_MESSAGE_ID, id)
                        .putExtra(EXTRA_STATUS, status)
                        .putExtra(EXTRA_RESULT_CODE, resultCode)
                        .putExtra(EXTRA_ERROR_CODE, errorCode)
                        .putExtra(EXTRA_TIME, time.getTime())
                        .setAction(ACTION_SEND_STATUS)
        );
    }

    public static void enqueueWork(Context context, String server) {
        JobIntentService.enqueueWork(context.getApplicationContext(), StatusReporterService.class, JOB_ID,
                new Intent()
                        .putExtra(EXTRA_SERVER, server)
                        .setAction(ACTION_SEND_PERIODIC_STATUS)
        );
    }

    @Override
    protected void onHandleWork(@NonNull Intent intent) {
        if (ACTION_SEND_STATUS.equals(intent.getAction())) {
            Long id = intent.getLongExtra(EXTRA_MESSAGE_ID, 0);
            String status = intent.getStringExtra(EXTRA_STATUS);
            int errorCode = intent.getIntExtra(EXTRA_ERROR_CODE, -1);
            int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, -1);
            Date time = new Date(intent.getLongExtra(EXTRA_TIME, 0));
            sendStatus(id, status, resultCode, errorCode, time);
        } else if (ACTION_SEND_PERIODIC_STATUS.equals(intent.getAction())) {
            String server = intent.getStringExtra(EXTRA_SERVER);
            sendPeriodicStatus(server);
        }
    }

    private void sendStatus(Long id, String status, int resultCode, int errorCode, Date time) {
        Box<Message> box = Message.getBox(this);
        Message message = box.get(id);
        if(message != null) {
            if (Objects.equals(message.getStatus(), "Failed")) {
                return;
            }

            boolean sendStatus = true;
            if (message.getType() == null || message.getType().equals("sms")) {
                if (message.getPendingParts() > 0) {
                    message.setPendingParts(message.getPendingParts() - 1);
                }

                sendStatus = status.equals("Failed") || message.getPendingParts() <= 0;
            }

            if (sendStatus) {
                message.setStatus(status);
                message.setResultCode(resultCode);
                message.setErrorCode(errorCode);
                message.setDeliveredDate(time);
                message.setDelivered(false);
                boolean result = message.sendStatus(this);
                if (result) {
                    Log.d(TAG, String.format("Status report of Message #%d sent successfully.", message.getID()));
                    return;
                } else {
                    Log.d(TAG, String.format("Unable to send status report of Message #%d.", message.getID()));
                }
            }
            box.put(message);
        }
    }

    private void sendPeriodicStatus(String server) {
        Log.d(TAG, "Periodic Status report job started.");
        List<Message> messages = Message.getBox(this).query().equal(Message_.server, server).notEqual(Message_.status, "Queued").equal(Message_.delivered, false).build().find();
        long messageCount = messages.size();
        if (messageCount > 0) {
            boolean result = Message.sendStatusReport(this, server, messages, true);
            if (result) {
                Log.d(TAG, String.format("Status report sent successfully for %d messages.", messageCount));
            } else {
                Log.d(TAG, String.format("Unable to send status report of %d messages.", messageCount));
            }
        } else {
            Log.d(TAG, "There are no status updates to send.");
        }
    }
}
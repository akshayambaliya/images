package org.rbsoft.smsgateway.services;

import android.content.Context;
import android.content.Intent;
import android.os.PersistableBundle;

import androidx.annotation.NonNull;
import androidx.core.app.JobIntentService;
import android.util.Log;

import org.rbsoft.smsgateway.BuildConfig;
import org.rbsoft.smsgateway.models.ReceivedMessage;

import java.util.Date;

import javax.annotation.Nonnull;

import static org.rbsoft.smsgateway.others.Common.*;

public class SmsReceiverService extends JobIntentService {

    private static final int JOB_ID = 15081947;

    private static final String ACTION_RECEIVE_SMS = "org.rbsoft.smsgateway.services.action.RECEIVE_SMS";
    private static final String ACTION_SEND_RECEIVED = "org.rbsoft.smsgateway.services.action.SEND_RECEIVED";

    public static void enqueueWork(Context context, String server, int userId, String number, String message, int simSlot, @Nonnull Date sentTime, @NonNull Date receivedTime) {
        JobIntentService.enqueueWork(context.getApplicationContext(), SmsReceiverService.class, JOB_ID,
                new Intent()
                        .putExtra(EXTRA_SERVER, server)
                        .putExtra(EXTRA_USER_ID, userId)
                        .putExtra(EXTRA_NUMBER, number)
                        .putExtra(EXTRA_MESSAGE, message)
                        .putExtra(EXTRA_SIM_SLOT, simSlot)
                        .putExtra(EXTRA_SENT_TIME, sentTime.getTime())
                        .putExtra(EXTRA_TIME, receivedTime.getTime())
                        .setAction(ACTION_RECEIVE_SMS)
        );
    }

    public static void enqueueWork(Context context, String server, int userId) {
        JobIntentService.enqueueWork(context.getApplicationContext(), SmsReceiverService.class, JOB_ID,
                new Intent()
                        .putExtra(EXTRA_SERVER, server)
                        .putExtra(EXTRA_USER_ID, userId)
                        .setAction(ACTION_SEND_RECEIVED)
        );
    }

    @Override
    protected void onHandleWork(@NonNull Intent intent) {
        String server = intent.getStringExtra(EXTRA_SERVER);
        int userId = intent.getIntExtra(EXTRA_USER_ID, 0);
        if (ACTION_RECEIVE_SMS.equals(intent.getAction())) {
            String number = intent.getStringExtra(EXTRA_NUMBER);
            String message = intent.getStringExtra(EXTRA_MESSAGE);
            int simSlot = intent.getIntExtra(EXTRA_SIM_SLOT, -1);
            Date sentTime = new Date(intent.getLongExtra(EXTRA_SENT_TIME, 0));
            Date receivedTime = new Date(intent.getLongExtra(EXTRA_TIME, 0));
            saveMessage(server, userId, number, message, simSlot, sentTime, receivedTime);
        } else if (ACTION_SEND_RECEIVED.equals(intent.getAction())) {
            ReceivedMessage.send(this, server, userId);
        }
    }

    private void saveMessage(String server, int userId, String number, String message, int simSlot, Date sentTime, Date receivedTime) {
        ReceivedMessage msg = new ReceivedMessage();
        msg.setServer(server);
        msg.setSentDate(sentTime);
        msg.setReceivedDate(receivedTime);
        msg.setDelivered(false);
        msg.setSimSlot(simSlot);
        msg.setNumber(number);
        msg.setMessage(message);
        msg.setUserID(userId);
        ReceivedMessage.getBox(this).put(msg);
        if (!ReceivedMessage.send(this, server, userId)) {
            PersistableBundle extras = new PersistableBundle(2);
            extras.putString(BUNDLE_SERVER, server);
            extras.putInt(BUNDLE_USER_ID, userId);
            boolean result = scheduleJob(getApplicationContext(), RECEIVER_JOB_ID, SmsReceiverJob.class.getName(), extras);
            if (BuildConfig.DEBUG) {
                if (result) {
                    Log.d(TAG, "Scheduled periodic sms receiver job recurring every 30 minutes.");
                } else {
                    Log.d(TAG, "Unable to schedule periodic sms receiver job recurring every 30 minutes.");
                }
            }
        }
    }
}
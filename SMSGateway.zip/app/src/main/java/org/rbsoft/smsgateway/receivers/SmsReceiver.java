package org.rbsoft.smsgateway.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.text.TextUtils;
import android.util.Log;

import org.rbsoft.smsgateway.BuildConfig;
import org.rbsoft.smsgateway.services.SmsReceiverService;

import java.util.Date;
import java.util.Objects;

import static android.provider.Telephony.Sms.Intents.SMS_RECEIVED_ACTION;
import static android.provider.Telephony.Sms.Intents.getMessagesFromIntent;
import static org.rbsoft.smsgateway.others.Common.PREF_READ_RECEIVED;
import static org.rbsoft.smsgateway.others.Common.PREF_SERVER;
import static org.rbsoft.smsgateway.others.Common.PREF_SETTINGS;
import static org.rbsoft.smsgateway.others.Common.PREF_USER_ID;
import static org.rbsoft.smsgateway.others.Common.TAG;

public class SmsReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (Objects.equals(intent.getAction(), SMS_RECEIVED_ACTION)) {
            SharedPreferences settings = context.getSharedPreferences(PREF_SETTINGS, Context.MODE_PRIVATE);
            final String server = settings.getString(PREF_SERVER, null);
            final int userId = settings.getInt(PREF_USER_ID, 0);
            if (!TextUtils.isEmpty(server) && userId != 0 && settings.getBoolean(PREF_READ_RECEIVED, true)) {
                final SmsMessage[] messages = getMessagesFromIntent(intent);

                // Check messages for validity
                if (messages == null || messages.length < 1) {
                    Log.d(TAG, "SmsReceiver: null or zero message");
                    return;
                }

                // Sometimes, SmsMessage.mWrappedSmsMessage is null causing NPE when we access
                // the methods on it although the SmsMessage itself is not null. So do this check
                // before we do anything on the parsed SmsMessages.
                try {
                    StringBuilder stringBuilder = new StringBuilder();
                    for (SmsMessage smsMessage : messages) {
                        stringBuilder.append(smsMessage.getDisplayMessageBody());
                    }

                    String number = messages[0].getDisplayOriginatingAddress();
                    Bundle bundle = intent.getExtras();

                    int simSlot = -1;
                    if (bundle != null) {
                        if (BuildConfig.DEBUG) {
                            for (String key : bundle.keySet()) {
                                Log.d(TAG, String.format("'%1$s' has value of '%2$s'", key, bundle.get(key)));
                            }
                        }
                        simSlot = bundle.getInt("slot", -1);
                    }


                    Date sentTime = new Date(messages[messages.length - 1].getTimestampMillis());
                    SmsReceiverService.enqueueWork(context, server, userId, number, stringBuilder.toString(), simSlot, sentTime, new Date());
                    Log.d(TAG, String.format("Received message from %1$s on SIM in slot index %2$d sent at %3$s", number, simSlot, sentTime));
                } catch (final NullPointerException e) {
                    Log.d(TAG, "shouldIgnoreMessage: NPE inside SmsMessage");
                }
            }
        }
    }
}

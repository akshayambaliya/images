package org.rbsoft.smsgateway.services;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.Context;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.PersistableBundle;

import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.text.TextUtils;
import android.util.Log;

import org.rbsoft.smsgateway.BuildConfig;
import org.rbsoft.smsgateway.R;
import org.rbsoft.smsgateway.models.*;
import org.rbsoft.smsgateway.ui.MainActivity;

import java.lang.reflect.Field;
import java.time.Instant;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

import retrofit2.Call;
import retrofit2.Response;

import static org.rbsoft.smsgateway.others.Common.*;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

/**
 * An {@link MyIntentService} subclass for handling asynchronous task requests in
 * a service on a separate handler thread.
 */
public class SendMessagesService extends MyIntentService {

    public static final String ACTION_STOP_SENDING_MESSAGES = "org.rbsoft.smsgateway.services.action.STOP_SENDING_MESSAGES";
    public static final String ACTION_PAUSE_RESUME_SENDING_MESSAGES = "org.rbsoft.smsgateway.services.action.PAUSE_RESUME_SENDING_MESSAGES";
    private static final String ACTION_SEND_MESSAGES = "org.rbsoft.smsgateway.services.action.SEND_MESSAGES";
    private static final String CHANNEL_SEND_MESSAGES = "CHANNEL_SEND_MESSAGES";

    private static final int ONGOING_NOTIFICATION_ID = 78648;
    private static final int REQUEST_OPEN_MAIN_ACTIVITY = 63354;
    private static final int REQUEST_STOP_SENDING_MESSAGES = 76456;
    private static final int REQUEST_PAUSE_RESUME_SENDING_MESSAGES = 81256;

    private BroadcastReceiver mPauseResumeReceiver;
    private NotificationManagerCompat mNotificationManager;
    private NotificationCompat.Builder mBuilder;
    private WakeLock mWakeLock;
    private boolean mPausable = true;
    private boolean mPaused = false;

    public static ArrayList<String> queue = new ArrayList<>();
    public static boolean cancel = false;

    public SendMessagesService() {
        super("SendMessagesService");
        setIntentRedelivery(true);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        mNotificationManager = NotificationManagerCompat.from(this);
        IntentFilter intentFilter = new IntentFilter(ACTION_PAUSE_RESUME_SENDING_MESSAGES);
        mPauseResumeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (mPausable) {
                    mPaused = !mPaused;
                    NotificationCompat.Action action;
                    PendingIntent pendingIntent =
                            PendingIntent.getBroadcast(getBaseContext(), REQUEST_PAUSE_RESUME_SENDING_MESSAGES, intent, PendingIntent.FLAG_ONE_SHOT);
                    String contentTitle = Objects.toString(mBuilder.build().extras.get(Notification.EXTRA_TITLE), getString(R.string.notification_title));
                    if (mPaused) {
                        mBuilder.setContentTitle(String.format("(%s) %s", getString(R.string.notification_title_paused), contentTitle));
                        action = new NotificationCompat.Action.Builder(R.drawable.ic_action_resume, getString(R.string.button_resume), pendingIntent).build();
                    } else {
                        mBuilder.setContentTitle(contentTitle.replace(String.format("(%s) ", getString(R.string.notification_title_paused)), ""));
                        action = new NotificationCompat.Action.Builder(R.drawable.ic_action_pause, getString(R.string.button_pause), pendingIntent).build();
                    }

                    try {
                        Field field = mBuilder.getClass().getDeclaredField("mActions");
                        field.setAccessible(true);
                        @SuppressWarnings("unchecked")
                        ArrayList<NotificationCompat.Action> mActions = (ArrayList<NotificationCompat.Action>) field.get(mBuilder);
                        if (mActions != null) {
                            mActions.set(0, action);
                            field.set(mBuilder, mActions);
                        }
                    } catch (NoSuchFieldException | IllegalAccessException e) {
                        e.printStackTrace();
                    }
                    mNotificationManager.notify(ONGOING_NOTIFICATION_ID, mBuilder.build());
                }
            }
        };
        registerReceiver(mPauseResumeReceiver, intentFilter);
    }

    /**
     * Starts this service to perform action SEND_MESSAGES with the given parameters. If
     * the service is already performing a task this action will be queued.
     *
     * @see MyIntentService
     */
    public static boolean startActionSendMessages(Context context, String server, String groupId, String sleepTime, String delay, boolean reportDelivery, boolean prioritize) {
        if (queue.contains(groupId)) {
            return false;
        }
        Intent intent = new Intent(context, SendMessagesService.class);
        intent.setAction(ACTION_SEND_MESSAGES);
        if (delay != null) {
            String[] delays = delay.split("-");
            intent.putExtra(EXTRA_MIN_DELAY, Integer.parseInt(delays[0]));
            if (delays.length >= 2) {
                intent.putExtra(EXTRA_MAX_DELAY, Integer.parseInt(delays[1]));
            }
        }
        intent.putExtra(EXTRA_GROUP_ID, groupId);
        intent.putExtra(EXTRA_SERVER, server);
        intent.putExtra(EXTRA_SLEEP_TIME, sleepTime);
        intent.putExtra(EXTRA_REPORT_DELIVERY, reportDelivery);
        intent.putExtra(EXTRA_PRIORITIZE, prioritize);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent);
        } else {
            context.startService(intent);
        }
        queue.add(groupId);
        return true;
    }

    private void requeue(String server, String groupId, String sleepTime, int minDelay, int maxDelay, boolean reportDelivery) {
        Intent intent = new Intent(getApplicationContext(), SendMessagesService.class)
                .setAction(ACTION_SEND_MESSAGES)
                .putExtra(EXTRA_MIN_DELAY, minDelay)
                .putExtra(EXTRA_MAX_DELAY, maxDelay)
                .putExtra(EXTRA_GROUP_ID, groupId)
                .putExtra(EXTRA_SERVER, server)
                .putExtra(EXTRA_SLEEP_TIME, sleepTime)
                .putExtra(EXTRA_REPORT_DELIVERY, reportDelivery)
                .putExtra(EXTRA_PRIORITIZE, false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getApplicationContext().startForegroundService(intent);
        } else {
            getApplicationContext().startService(intent);
        }
        queue.add(groupId);
    }

    public void scheduleActionSendMessages(String server, String groupId, String sleepTime, int minDelay, int maxDelay, boolean reportDelivery, long schedule) {
        Intent intent = new Intent(getApplicationContext(), SendMessagesService.class)
                .setAction(ACTION_SEND_MESSAGES)
                .putExtra(EXTRA_MIN_DELAY, minDelay)
                .putExtra(EXTRA_MAX_DELAY, maxDelay)
                .putExtra(EXTRA_GROUP_ID, groupId)
                .putExtra(EXTRA_SERVER, server)
                .putExtra(EXTRA_SLEEP_TIME, sleepTime)
                .putExtra(EXTRA_REPORT_DELIVERY, reportDelivery)
                .putExtra(EXTRA_PRIORITIZE, false);

        PendingIntent pendingIntent;
        int requestCode = ThreadLocalRandom.current().nextInt(0, Integer.MAX_VALUE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            pendingIntent = PendingIntent.getForegroundService(getApplicationContext(), requestCode, intent, PendingIntent.FLAG_ONE_SHOT | PendingIntent.FLAG_CANCEL_CURRENT);
        } else {
            pendingIntent = PendingIntent.getService(getApplicationContext(), requestCode, intent, PendingIntent.FLAG_ONE_SHOT | PendingIntent.FLAG_CANCEL_CURRENT);
        }

        AlarmManager alarmManager = (AlarmManager) getApplicationContext().getSystemService(Context.ALARM_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, schedule, pendingIntent);
        } else {
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, schedule, pendingIntent);
        }

        Log.d(TAG, String.format("Alarm schedule for %s using PendingIntent with %d as its request code.", Instant.ofEpochMilli(schedule).atZone(ZoneId.systemDefault()), requestCode));
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        Log.d(TAG, "onHandleIntent");
        if (intent != null) {
            Intent notificationIntent = new Intent(this, MainActivity.class);
            PendingIntent pendingIntent =
                    PendingIntent.getActivity(this, REQUEST_OPEN_MAIN_ACTIVITY, notificationIntent, PendingIntent.FLAG_CANCEL_CURRENT);

            Intent cancelIntent = new Intent(this, MainActivity.class).setAction(ACTION_STOP_SENDING_MESSAGES);
            PendingIntent cancelPendingIntent =
                    PendingIntent.getActivity(this, REQUEST_STOP_SENDING_MESSAGES, cancelIntent, PendingIntent.FLAG_CANCEL_CURRENT);

            Intent pauseResumeIntent = new Intent(ACTION_PAUSE_RESUME_SENDING_MESSAGES);
            PendingIntent pauseResumePendingIntent =
                    PendingIntent.getBroadcast(getBaseContext(), REQUEST_PAUSE_RESUME_SENDING_MESSAGES, pauseResumeIntent, PendingIntent.FLAG_ONE_SHOT);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel notificationChannel = new NotificationChannel(CHANNEL_SEND_MESSAGES, getText(R.string.notification_channel_name), NotificationManager.IMPORTANCE_HIGH);
                mNotificationManager.createNotificationChannel(notificationChannel);
            }

            mBuilder = new NotificationCompat.Builder(this, CHANNEL_SEND_MESSAGES)
                    .setContentTitle(getText(R.string.notification_title))
                    .setProgress(100, 0, true)
                    .setSmallIcon(R.drawable.ic_notification)
                    .addAction(new NotificationCompat.Action.Builder(R.drawable.ic_action_pause, getString(R.string.button_pause), pauseResumePendingIntent).build())
                    .addAction(new NotificationCompat.Action.Builder(R.drawable.ic_action_cancel, getString(R.string.button_cancel), cancelPendingIntent).build())
                    .setOnlyAlertOnce(true)
                    .setContentIntent(pendingIntent);
            startForeground(ONGOING_NOTIFICATION_ID, mBuilder.build());

            PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
            mWakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SendMessagesService::WakeLock");
            mWakeLock.acquire();
            if (ACTION_SEND_MESSAGES.equals(intent.getAction())) {
                int minDelay = intent.getIntExtra(EXTRA_MIN_DELAY, 0);
                int maxDelay = intent.getIntExtra(EXTRA_MAX_DELAY, 0);
                String groupId = intent.getStringExtra(EXTRA_GROUP_ID);
                String server = intent.getStringExtra(EXTRA_SERVER);
                String sleepTime = intent.getStringExtra(EXTRA_SLEEP_TIME);
                boolean prioritize = intent.getBooleanExtra(EXTRA_PRIORITIZE, false);
                boolean reportDelivery = intent.getBooleanExtra(EXTRA_REPORT_DELIVERY, false);
                handleActionSendMessages(server, groupId, sleepTime, minDelay, maxDelay, reportDelivery, prioritize);
            }
            if (mWakeLock.isHeld()) {
                mWakeLock.release();
            }
        }
    }

    /**
     * Handle action SEND_MESSAGES in the provided background thread with the provided
     * parameters.
     */
    private void handleActionSendMessages(String server, String groupId, String sleepTime, int minDelay, int maxDelay, boolean reportDelivery, boolean prioritize) {
        try {
            cancel = false;
            mPaused = false;
            mPausable = true;
            int count = 0;
            int totalCount = 0;
            SharedPreferences sharedPreferences = getSharedPreferences(PREF_SETTINGS, Context.MODE_PRIVATE);
            Message.count = sharedPreferences.getInt(PREF_MESSAGES_SEND, 0);
            Log.d(TAG, String.format("Count is at %d", Message.count));
            Log.d(TAG, String.format("reportDelivery value is %s", reportDelivery));
            infiniteLoop:
            while (true) {
                MyWebService myWebService = getWebService(server);
                Call<JsonResponse> getMessagesCall = myWebService.getMessages(groupId, 100);
                Response<JsonResponse> response = getMessagesCall.execute();
                if (response.isSuccessful()) {
                    JsonResponse jsonResponse = response.body();
                    if (jsonResponse != null) {
                        if (jsonResponse.getSuccess()) {
                            List<Message> messages = jsonResponse.getData().getMessages();
                            if (messages.size() == 0) {
                                break;
                            }
                            if (count == 0) {
                                totalCount = jsonResponse.getData().getTotalCount();
                                Log.d(TAG, String.format("There are %d messages to send.", totalCount));
                                mBuilder.setContentTitle(String.format(getString(R.string.notification_progress_title), count, totalCount))
                                        .setProgress(totalCount, count, false);
                                mNotificationManager.notify(ONGOING_NOTIFICATION_ID, mBuilder.build());
                            }
                            for (int i = 0; i < messages.size(); i++) {
                                do {
                                    if (!prioritize) {
                                        // If there is prioritized campaign in queue and current campaign is not prioritized campaign then cancel it and requeue it.
                                        if (prioritizedIntents > 0) {
                                            cancel = true;
                                            requeue(server, groupId, sleepTime, minDelay, maxDelay, reportDelivery);
                                            Log.d(TAG, String.format("There are %d prioritized campaigns in queue. Canceling this one and adding it to end of the queue cause it isn't prioritized.", prioritizedIntents));
                                        } else if (isCurrentTimeBetween(sleepTime)) {
                                            // If time is between sleep time and current campaign is not prioritized then cancel it and schedule it after sleep time.
                                            cancel = true;
                                            scheduleActionSendMessages(server, groupId, sleepTime, minDelay, maxDelay, reportDelivery, getTimestampAfter(sleepTime));
                                        }
                                    }
                                    if (cancel) {
                                        List<Message> remaining = messages.subList(i, messages.size());
                                        Message.sendStatusReport(this, server, remaining, false);
                                        Log.d(TAG, String.format("Cancel is set to true so setting %d remaining messages status to Pending", remaining.size()));
                                        break infiniteLoop;
                                    }
                                } while (mPaused);
                                if (count == totalCount - 1) {
                                    mPausable = false;
                                }
                                Message message = messages.get(i);
                                if (TextUtils.isEmpty(message.getType())) {
                                    message.setType("sms");
                                }
                                Log.d(TAG, String.format("Sending message #%1$d as %2$s.", message.getID(), message.getType().toUpperCase()));
                                message.setServer(server);
                                message.send(this, reportDelivery);
                                count++;
                                Log.d(TAG, String.format("The send function executed successfully for Message #%d.", message.getID()));
                                mBuilder.setProgress(totalCount, count, false)
                                        .setContentTitle(String.format(getString(R.string.notification_progress_title), count, totalCount));
                                mNotificationManager.notify(ONGOING_NOTIFICATION_ID, mBuilder.build());
                                if (minDelay > 0) {
                                    int delay = minDelay;
                                    if (maxDelay > 0) {
                                        delay = new Random().nextInt((maxDelay - minDelay) + 1) + minDelay;
                                    }
                                    Log.d(TAG, String.format("Waiting for %1$d seconds before sending another message…", delay));
                                    try {
                                        Thread.sleep(delay * 1000L);
                                    } catch (InterruptedException e) {
                                        e.printStackTrace();
                                    }
                                }
                            }
                        } else {
                            throw new Exception(jsonResponse.getError().getMessage());
                        }
                    }
                } else {
                    throw new Exception(String.format("%s %s", response.code(), response.message()));
                }
            }
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putInt(PREF_MESSAGES_SEND, Message.count);
            editor.apply();
            PersistableBundle extras = new PersistableBundle(1);
            extras.putString(BUNDLE_SERVER, server);
            boolean result = scheduleJob(this, STATUS_REPORTER_JOB_ID, StatusReporterJob.class.getName(), extras);
            if (BuildConfig.DEBUG) {
                if (result) {
                    Log.d(TAG, "Scheduled periodic status report job recurring every 30 minutes.");
                } else {
                    Log.d(TAG, "Unable to schedule periodic status report job recurring every 30 minutes.");
                }
            }
            stopForeground(true);
        } catch (Exception e) {
            mPausable = false;
            Log.d(TAG, String.format("getMessages : %s", e.getMessage()));
            mBuilder.setProgress(0, 0, false)
                    .setContentText(getString(R.string.notification_error_text))
                    .setContentTitle(getString(R.string.notification_error_title))
                    .setStyle(new NotificationCompat.BigTextStyle()
                            .bigText(e.getMessage()));
            mNotificationManager.notify(ONGOING_NOTIFICATION_ID, mBuilder.build());
            stopForeground(false);
        } finally {
            queue.remove(groupId);
        }
    }

    @Override
    public void onDestroy() {
        if (mWakeLock != null && mWakeLock.isHeld()) {
            mWakeLock.release();
        }
        unregisterReceiver(mPauseResumeReceiver);
        super.onDestroy();
    }
}
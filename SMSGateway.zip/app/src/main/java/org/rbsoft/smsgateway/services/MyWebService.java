package org.rbsoft.smsgateway.services;

import org.rbsoft.smsgateway.models.JsonResponse;
import org.rbsoft.smsgateway.models.Update;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface MyWebService {

    @POST("services/register-device.php")
    @FormUrlEncoded
    Call<JsonResponse> registerDevice(@Field("email") String email,
                                      @Field("password") String password,
                                      @Field("androidId") String androidId,
                                      @Field("model") String model,
                                      @Field("sims") String sims,
                                      @Field("androidVersion") String androidVersion,
                                      @Field("appVersion") String appVersion);

    @POST("services/register-device.php")
    @FormUrlEncoded
    Call<JsonResponse> registerDevice(@Field("key") String key,
                                      @Field("androidId") String androidId,
                                      @Field("model") String model,
                                      @Field("sims") String sims,
                                      @Field("androidVersion") String androidVersion,
                                      @Field("appVersion") String appVersion);

    @POST("services/sign-in.php")
    @FormUrlEncoded
    Call<JsonResponse> signIn(@Field("androidId") String androidId,
                              @Field("userId") int userId,
                              @Field("sims") String sims,
                              @Field("androidVersion") String androidVersion,
                              @Field("appVersion") String appVersion);

    @POST("services/update-token.php")
    @FormUrlEncoded
    Call<JsonResponse> updateToken(@Field("androidId") String androidId,
                                   @Field("userId") int userId,
                                   @Field("token") String token);

    @POST("services/sign-out.php")
    @FormUrlEncoded
    Call<JsonResponse> signOut(@Field("androidId") String androidId,
                               @Field("userId") int userId);

    @POST("services/get-messages.php")
    @FormUrlEncoded
    Call<JsonResponse> getMessages(@Field("groupId") String groupId, @Field("limit") int limit);

    @POST("services/report-status.php")
    @FormUrlEncoded
    Call<JsonResponse> sendStatusReport(@Field("messages") String messages);


    @POST("services/receive-message.php")
    @FormUrlEncoded
    Call<JsonResponse> sendReceivedMessage(@Field("androidId") String androidId,
                                           @Field("userId") int userId,
                                           @Field("messages") String messages);

    @POST("services/get-campaigns.php")
    @FormUrlEncoded
    Call<JsonResponse> getCampaigns(@Field("androidId") String androidId,
                                    @Field("userId") int userId,
                                    @Field("versionCode") int versionCode);

    @GET("services/update.php")
    Call<Update> checkForUpdate();
}

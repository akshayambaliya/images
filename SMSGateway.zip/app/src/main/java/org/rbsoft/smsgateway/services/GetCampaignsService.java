package org.rbsoft.smsgateway.services;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;

import org.rbsoft.smsgateway.BuildConfig;
import org.rbsoft.smsgateway.R;
import org.rbsoft.smsgateway.models.JsonResponse;
import org.rbsoft.smsgateway.ui.MainActivity;

import retrofit2.Call;
import retrofit2.Response;

import static org.rbsoft.smsgateway.others.Common.*;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

public class GetCampaignsService extends Service {
    private static final String CHANNEL_GET_CAMPAIGNS = "CHANNEL_GET_CAMPAIGNS";

    private static final int ONGOING_NOTIFICATION_ID = 632;
    private static final int REQUEST_OPEN_MAIN_ACTIVITY = 52543;

    private boolean mIsRunning = false;
    private NotificationCompat.Builder mBuilder;
    private NotificationManagerCompat mNotificationManager;
    private WakeLock mWakeLock;

    @Override
    public void onCreate() {
        mNotificationManager = NotificationManagerCompat.from(this);
        Intent notificationIntent = new Intent(this, MainActivity.class);

        PendingIntent pendingIntent =
                PendingIntent.getActivity(this, REQUEST_OPEN_MAIN_ACTIVITY, notificationIntent, PendingIntent.FLAG_CANCEL_CURRENT);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel notificationChannel = new NotificationChannel(CHANNEL_GET_CAMPAIGNS, getText(R.string.notification_channel_name_get_campaigns), NotificationManager.IMPORTANCE_HIGH);
            mNotificationManager.createNotificationChannel(notificationChannel);
        }

        mBuilder = new NotificationCompat.Builder(this, CHANNEL_GET_CAMPAIGNS)
                .setContentTitle(getText(R.string.notification_title_get_campaigns))
                .setSmallIcon(R.drawable.ic_notification)
                .setOnlyAlertOnce(true)
                .setContentIntent(pendingIntent);
        startForeground(ONGOING_NOTIFICATION_ID, mBuilder.build());
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        mWakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GetCampaignsService::WakeLock");
        mWakeLock.acquire();
        mIsRunning = true;
        new Thread() {
            @Override
            public void run() {
                SharedPreferences sharedPreferences = getSharedPreferences(PREF_SETTINGS, Context.MODE_PRIVATE);
                final String server = sharedPreferences.getString(PREF_SERVER, null);
                final String androidId = getAndroidId(getApplicationContext());
                final int userId = sharedPreferences.getInt(PREF_USER_ID, 0);
                MyWebService myWebService = getWebService(server);
                int count = 0;
                boolean anyErrors = true;

                while (mIsRunning) {
                    try {
                        Call<JsonResponse> getMessagesCall = myWebService.getCampaigns(androidId, userId, BuildConfig.VERSION_CODE);
                        Response<JsonResponse> response = getMessagesCall.execute();
                        if (response.isSuccessful()) {
                            if (anyErrors) {
                                mBuilder.setContentTitle(getText(R.string.notification_title_get_campaigns))
                                        .setContentText(String.format(getString(R.string.notification_text_get_campaigns), count))
                                        .setStyle(null);
                                mNotificationManager.notify(ONGOING_NOTIFICATION_ID, mBuilder.build());
                                anyErrors = false;
                            }
                            JsonResponse jsonResponse = response.body();
                            if (jsonResponse != null) {
                                if (jsonResponse.getSuccess()) {
                                    int lastCount = count;
                                    String delay = jsonResponse.getData().getUser().getDelay();
                                    String sleepTime = jsonResponse.getData().getUser().getSleepTime();
                                    boolean reportDelivery = jsonResponse.getData().getUser().getReportDelivery() == 1;
                                    if (jsonResponse.getData().getPrioritizedCampaigns() != null) {
                                        for (String groupID : jsonResponse.getData().getPrioritizedCampaigns()) {
                                            boolean result = SendMessagesService.startActionSendMessages(getApplicationContext(), server, groupID, sleepTime, delay, reportDelivery, true);
                                            if (result) {
                                                count++;
                                            }
                                        }
                                    }
                                    if (!isCurrentTimeBetween(sleepTime)) {
                                        for (String groupID : jsonResponse.getData().getCampaigns()) {
                                            boolean result = SendMessagesService.startActionSendMessages(getApplicationContext(), server, groupID, sleepTime, delay, reportDelivery, false);
                                            if (result) {
                                                count++;
                                            }
                                        }
                                    }
                                    if (count > lastCount) {
                                        mBuilder.setContentText(String.format(getString(R.string.notification_text_get_campaigns), count))
                                                .setStyle(null);
                                        mNotificationManager.notify(ONGOING_NOTIFICATION_ID, mBuilder.build());
                                    }
                                } else {
                                    throw new Exception(jsonResponse.getError().getMessage());
                                }
                            }
                        } else {
                            throw new Exception(String.format("%s %s", response.code(), response.message()));
                        }
                    } catch (Exception e) {
                        anyErrors = true;
                        mBuilder.setContentText(e.getMessage())
                                .setStyle(new NotificationCompat.BigTextStyle()
                                        .bigText(e.getMessage()));
                        mNotificationManager.notify(ONGOING_NOTIFICATION_ID, mBuilder.build());
                    } finally {
                        try {
                            sleep(30000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
                if (mWakeLock.isHeld()) {
                    mWakeLock.release();
                }
            }
        }.start();

        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        mIsRunning = false;
        if (mWakeLock != null && mWakeLock.isHeld()) {
            mWakeLock.release();
        }
        super.onDestroy();
    }
}

package org.rbsoft.smsgateway.services;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.os.PersistableBundle;

import static org.rbsoft.smsgateway.others.Common.BUNDLE_SERVER;
import static org.rbsoft.smsgateway.others.Common.BUNDLE_USER_ID;

public class SmsReceiverJob extends JobService {
    @Override
    public boolean onStartJob(JobParameters jobParameters) {
        PersistableBundle persistableBundle = jobParameters.getExtras();
        String server = persistableBundle.getString(BUNDLE_SERVER);
        int userId = persistableBundle.getInt(BUNDLE_USER_ID, 0);
        SmsReceiverService.enqueueWork(this, server, userId);
        return false;
    }

    @Override
    public boolean onStopJob(JobParameters jobParameters) {
        return false;
    }
}

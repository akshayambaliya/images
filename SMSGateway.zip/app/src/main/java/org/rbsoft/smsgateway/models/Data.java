package org.rbsoft.smsgateway.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Data {

    @SerializedName("senderId")
    @Expose
    private String senderId;
    @SerializedName("sessionId")
    @Expose
    private String sessionId;
    @SerializedName("device")
    @Expose
    private Device device;
    @SerializedName("purchaseCode")
    @Expose
    private String purchaseCode;
    @SerializedName("user")
    @Expose
    private User user;
    @SerializedName("totalCount")
    @Expose
    private int totalCount;
    @SerializedName("messages")
    @Expose
    private List<Message> messages = null;
    @SerializedName("campaigns")
    @Expose
    private List<String> campaigns = null;
    @SerializedName("prioritizedCampaigns")
    @Expose
    private List<String> prioritizedCampaigns = null;

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public Device getDevice() {
        return device;
    }

    public void setDevice(Device device) {
        this.device = device;
    }

    public String getSenderId() {
        return senderId;
    }

    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public List<Message> getMessages() {
        return messages;
    }

    public void setMessages(List<Message> messages) {
        this.messages = messages;
    }

    public List<String> getCampaigns() {
        return campaigns;
    }

    public void setCampaigns(List<String> campaigns) {
        this.campaigns = campaigns;
    }

    public List<String> getPrioritizedCampaigns() {
        return prioritizedCampaigns;
    }

    public void setPrioritizedCampaigns(List<String> prioritizedCampaigns) {
        this.prioritizedCampaigns = prioritizedCampaigns;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getPurchaseCode() {
        return purchaseCode;
    }

    public void setPurchaseCode(String purchaseCode) {
        this.purchaseCode = purchaseCode;
    }
}

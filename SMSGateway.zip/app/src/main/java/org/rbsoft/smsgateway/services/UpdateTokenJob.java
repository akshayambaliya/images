package org.rbsoft.smsgateway.services;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;

import com.google.firebase.iid.FirebaseInstanceId;

import org.rbsoft.smsgateway.models.JsonResponse;

import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import retrofit2.Call;
import retrofit2.Response;

import static org.rbsoft.smsgateway.others.Common.*;

public class UpdateTokenJob extends JobService {

    Future<?> mFuture;

    @Override
    public boolean onStartJob(JobParameters params) {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        mFuture = executor.submit(() -> {
            SharedPreferences settings = getSharedPreferences(PREF_SETTINGS, Context.MODE_PRIVATE);
            String server = settings.getString(PREF_SERVER, "");
            String senderId = settings.getString(PREF_SENDER_ID, "");
            int userId = settings.getInt(PREF_USER_ID, 0);

            if (TextUtils.isEmpty(server) || TextUtils.isEmpty(senderId) || userId == 0) {
                jobFinished(params, false);
                return;
            }

            MyWebService myWebService = getWebService(server);
            try {
                String token = FirebaseInstanceId.getInstance().getToken(senderId, "FCM");
                Call<JsonResponse> registerDeviceCall = myWebService.updateToken(getAndroidId(getApplicationContext()), userId, token);
                Response<JsonResponse> response = registerDeviceCall.execute();
                if (response.isSuccessful()) {
                    JsonResponse jsonResponse = response.body();
                    if (jsonResponse != null) {
                        if (jsonResponse.getSuccess()) {
                            jobFinished(params, false);
                            return;
                        }
                    }
                }
            } catch (IOException ignored) {
            }
            jobFinished(params, true);
        });

        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        if (mFuture.isDone()) {
            return false;
        } else {
            mFuture.cancel(true);
            return true;
        }
    }
}

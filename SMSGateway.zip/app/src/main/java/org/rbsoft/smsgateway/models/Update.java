package org.rbsoft.smsgateway.models;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import org.rbsoft.smsgateway.services.MyWebService;

import retrofit2.Call;
import retrofit2.Response;

import static org.rbsoft.smsgateway.others.Common.PREF_SERVER;
import static org.rbsoft.smsgateway.others.Common.PREF_SETTINGS;
import static org.rbsoft.smsgateway.others.Common.getWebService;

public class Update {

    public static final String PREF_LATEST_VERSION_CODE = "PREF_LATEST_VERSION_CODE";
    public static final String PREF_LATEST_VERSION_URL = "PREF_LATEST_VERSION_URL";
    private static final String PREF_LAST_CHECK = "PREF_LAST_CHECK";
    @SerializedName("versionCode")
    @Expose
    private int versionCode;

    @SerializedName("url")
    @Expose
    private String url;

    public static void check(Context context) {
        try {
            SharedPreferences sharedPreferences = context.getSharedPreferences(PREF_SETTINGS, Context.MODE_PRIVATE);
            long lastCheck = sharedPreferences.getLong(PREF_LAST_CHECK, 0);
            if (lastCheck != 0 && (lastCheck + 3600) > (System.currentTimeMillis() / 1000)) {
                return;
            }

            String server = sharedPreferences.getString(PREF_SERVER, null);
            if (TextUtils.isEmpty(server)) {
                return;
            }

            MyWebService updateService = getWebService(server);
            Call<Update> checkForUpdateCall = updateService.checkForUpdate();
            Response<Update> response = checkForUpdateCall.execute();
            if (response.isSuccessful() && response.body() != null) {
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putLong(PREF_LAST_CHECK, System.currentTimeMillis() / 1000);
                editor.putLong(PREF_LATEST_VERSION_CODE, response.body().getVersionCode());
                editor.putString(PREF_LATEST_VERSION_URL, response.body().getUrl());
                editor.apply();
            }
        } catch (Exception ignored) {
        }
    }

    public int getVersionCode() {
        return versionCode;
    }

    public void setVersionCode(int versionCode) {
        this.versionCode = versionCode;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
